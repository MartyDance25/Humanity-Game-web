# Cards retain ordinary integer scoring while carrying a persistent physical face.
init -5 python:
    HG_SUITS = ('spade', 'heart', 'club', 'diamond')
    HG_SUIT_NAMES = {'spade':'黑桃', 'heart':'红桃', 'club':'梅花', 'diamond':'方块'}

    class HGCard(int):
        def __new__(cls, rank, suit, copy_id=0):
            card = int.__new__(cls, rank)
            card.suit = suit
            card.copy_id = copy_id
            return card

        def __reduce__(self):
            return HGCard, (int(self), self.suit, self.copy_id)

    def hg_card_key(card):
        return (int(card), getattr(card, 'suit', None), getattr(card, 'copy_id', 0))

    def hg_card_sort_key(card):
        return (int(card), HG_SUITS.index(card.suit) if hasattr(card, 'suit') else -1,
            getattr(card, 'copy_id', 0))

    def hg_card_name(card):
        rank = {11:'J', 12:'Q', 13:'K', 14:'A'}.get(int(card), str(int(card)))
        return HG_SUIT_NAMES.get(getattr(card, 'suit', None), '花色未知') + rank

    def hg_card_ink(card):
        return '#b52c3b' if getattr(card, 'suit', None) in ('heart', 'diamond') else '#202a35'

    def hg_card_icon(card):
        return 'gui/cards/{}.svg'.format(getattr(card, 'suit', 'unknown'))

    def hg_discard_card(person, card):
        # Equal ranks may have different suits: remove the exact card selected.
        if hasattr(card, 'suit'):
            index = next(i for i, held in enumerate(person['hand'])
                if hg_card_key(held) == hg_card_key(card))
        else:
            index = person['hand'].index(card)
        person['hand'].pop(index)

    def hg_restore_card_faces():
        # Older saves only stored ranks. Assign their remaining cards unused faces
        # deterministically, once on loading, without changing ranks or scores.
        piles = list(hg_rooms.values()) + [p['hand'] for p in hg_players]
        used = {hg_card_key(card) for pile in piles for card in pile if hasattr(card, 'suit')}
        available = {rank: [HGCard(rank, suit, copy_id)
            for copy_id in range(2) for suit in HG_SUITS
            if (rank, suit, copy_id) not in used] for rank in range(2,15)}
        for pile in piles:
            for index, card in enumerate(pile):
                if not hasattr(card, 'suit'):
                    pile[index] = available[int(card)].pop(0)

    config.after_load_callbacks.append(hg_restore_card_faces)

screen pg_playing_card(card, width=90, height=126):
    $ ink = hg_card_ink(card)
    $ rank = pg_rank(card)
    fixed:
        xsize width
        ysize height
        add 'gui/cards/face.svg' xysize (width,height)
        text rank font 'fonts/SourceHanSansSC-Regular.otf' color ink size int(width*.24) xpos int(width*.1) ypos int(height*.035)
        add hg_card_icon(card) xpos int(width*.1) ypos int(height*.26) xysize (int(width*.19),int(width*.19))
        add hg_card_icon(card) xalign .5 yalign .52 xysize (int(width*.44),int(width*.44))
        text rank font 'fonts/SourceHanSansSC-Regular.otf' color ink size int(width*.24) xalign .9 yalign .96

screen pg_hand_cards(width=90, height=126, area_width=900):
    if pg_you()['hand']:
        viewport:
            xsize area_width
            ysize height+18
            mousewheel 'horizontal'
            draggable True
            scrollbars 'horizontal'
            hbox:
                spacing 12
                for card in sorted(pg_you()['hand'], key=hg_card_sort_key):
                    use pg_playing_card(card, width, height)
    else:
        text '暂无普通牌' style 'pg_small'
