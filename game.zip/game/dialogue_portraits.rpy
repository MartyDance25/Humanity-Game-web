default pg_dialogue_pair = []

init 15 python:
    def pg_set_dialogue(first=None, second=None):
        global pg_dialogue_pair
        if first is None or second is None or first==second:
            pg_dialogue_pair=[]
            return
        if set(pg_dialogue_pair)=={first,second}:
            return
        pair=[first,second]
        if PG_ID in pair and pair[0]!=PG_ID:
            pair.reverse()
        pg_dialogue_pair=pair

    def pg_dialogue_people(who=None):
        if who=='主持人' or len(pg_dialogue_pair)!=2:
            return []
        if any(not 0<=pid<len(hg_players) for pid in pg_dialogue_pair):
            return []
        return pg_dialogue_pair

screen pg_dialogue_portraits(people, who=None, compact=False):
    $ speakers = [pid for pid in people if who and hg_players[pid]['name']==who]
    $ listeners = [pid for pid in people if pid not in speakers]
    $ ordered = speakers + listeners if speakers else list(people)
    for side,pid in enumerate(ordered):
        $ person=hg_players[pid]
        $ speaking=who==person['name']
        $ face_size=220 if compact else 430
        $ panel_width=260 if compact else 480
        $ panel_height=330 if compact else 545
        $ panel_x=(50 if side==0 else 1610) if compact else (65 if side==0 else 1375)
        frame:
            xpos panel_x ypos (240 if compact else 170)
            xsize panel_width ysize panel_height
            padding (4,4)
            background Solid('#c9aa69' if speaking else '#3b4d59')
            frame:
                xfill True yfill True
                padding (14,14)
                background Solid('#18242f')
                vbox:
                    xalign .5
                    spacing 8
                    add pg_portrait(pid) xysize (face_size,face_size) xalign .5
                    text person['name'] style 'pg_text' xalign .5 text_align .5 xmaximum face_size
                    text ('正在说话' if speaking else '倾听' if who else '交谈中') style 'pg_small' size 18 xalign .5
