style pg_text is default:
    font "fonts/SourceHanSansSC-Regular.otf"
    size 26
    color '#e2e7e8'
style pg_title is pg_text:
    size 44
    color '#e8cf98'
style pg_small is pg_text:
    size 21
    color '#a9b9c2'
style pg_button is button:
    background Solid('#253541')
    hover_background Solid('#3a5765')
    insensitive_background Solid('#1a242b')
    padding (22,14)
style pg_button_text is pg_text:
    hover_color '#fff3cc'
    insensitive_color '#5b6972'
style pg_panel is frame:
    background Solid('#18242fee')
    padding (28,24)
style pg_dialogue_window is default:
    padding (45,30)
    background Solid('#1b2a36')
style pg_card_button is pg_button:
    xsize 112
    ysize 150
    background Solid('#e5ded0')
    hover_background Solid('#fff4dc')
style pg_card_button_text is pg_text:
    color '#29333c'
    hover_color '#16232b'
    size 42
    xalign .5
    yalign .5

screen pg_header(title="个人策略战"):
    $ me = pg_you()
    frame:
        background Solid('#101820')
        xpos 40 ypos 24 xsize 1840 ysize 105
        hbox:
            spacing 40
            vbox:
                text "HUMANITY / 第一关" style 'pg_small'
                text title style 'pg_title'
            null width 45
            vbox:
                text "第 [hg_round] / 12 回合" style 'pg_text'
                text "26人入场 / 16人生还" style 'pg_small'
            vbox:
                text "积分 [me['score']]" style 'pg_text'
                $ now_total = hg_total(me)
                text "你的当前总分 [now_total]" style 'pg_small'
            vbox:
                $ hand_count = len(me['hand'])
                text "手牌 [hand_count] 张" style 'pg_text'
                text "强制机会 [me['force']] / 2" style 'pg_small'

screen pg_action():
    modal True
    add Solid('#101820')
    use pg_header('选择本回合主行动')
    $ me = pg_you()
    $ loc = me['room']
    $ local_name = PG_ROOMS[loc]
    $ remaining = len(hg_rooms[loc])
    frame:
        style 'pg_panel'
        xpos 45 ypos 155 xsize 1180 ysize 590
        vbox:
            spacing 15
            text "[loc] / [local_name]" style 'pg_title'
            text "场景剩余 [remaining] 张牌。选择后立即执行，主行动阶段结束后再交谈；也可以等待。" style 'pg_small'
            hbox:
                spacing 16
                textbutton "搜寻一张牌" style 'pg_button' sensitive hg_can_search(me) action Return(('search',None))
                textbutton "等待" style 'pg_button' action Return(('wait',None))
                textbutton "情报 / 记录" style 'pg_button' action Show('pg_info',tab='intel')
                textbutton "保存" style 'pg_button' sensitive not mp_is_active() action ShowMenu('save')
            text "不得连续两回合搜牌；上回合搜过，本回合须移动、挑战或等待。" style 'pg_small'
            text "同场景的人" style 'pg_text'
            viewport:
                mousewheel True
                scrollbars 'vertical'
                ysize 350
                vbox:
                    spacing 10
                    for p in hg_players:
                        if p['id'] != PG_ID and p['room'] == loc:
                            hbox:
                                spacing 20
                                add pg_portrait(p['id']) xysize (112,112)
                                vbox:
                                    xsize 640
                                    text p['name'] style 'pg_text'
                                    $ count = len(p['hand'])
                                    text ("手牌 {} 张 / 积分 {}".format(count,p['score']) if p['id']==PG_ID else "手牌 {} 张 / 积分保密".format(count)) style 'pg_small'
                                    text p['opening'] style 'pg_small'
                                textbutton "挑战" style 'pg_button' sensitive p in pg_targets(me) action Return(('challenge',p['id']))
                    if not any(p['id'] != PG_ID and p['room'] == loc for p in hg_players):
                        text "这里暂时只有你。" style 'pg_small'
    frame:
        style 'pg_panel'
        xpos 1250 ypos 155 xsize 625 ysize 875
        vbox:
            text "通道图" style 'pg_title'
            text "金色是你的位置，绿色可移动。\n每次只能走一条连线；所有通道双向。" style 'pg_small'
            fixed:
                xsize 570 ysize 670
                add PGMapLines() zoom .9
                for room_id, xy in PG_POS.items():
                    $ nx, ny = int(xy[0]*.9), int(xy[1]*.9)
                    $ node_color = '#8b7240' if room_id == loc else '#28564f' if room_id in HG_MAP[loc] else '#253541'
                    $ remain = len(hg_rooms[room_id])
                    $ room_name = PG_ROOMS[room_id]
                    $ occupants = mp_room_count(room_id)
                    textbutton "[room_name]\n[occupants]人\n余[remain]张":
                        id ('pg_move_'+str(room_id))
                        style 'pg_button'
                        text_size 18
                        text_text_align .5
                        padding (5,5)
                        text_insensitive_color '#a9b9c2'
                        text_xalign .5
                        xpos nx ypos ny xsize 92 ysize 78
                        background Solid(node_color)
                        sensitive room_id in HG_MAP[loc]
                        action Return(('move',room_id))
            textbutton "公开名册 / 规则" style 'pg_button' action Show('pg_info',tab='roster')
    frame:
        style 'pg_panel'
        xpos 45 ypos 770 xsize 1180 ysize 260
        hbox:
            spacing 24
            add pg_portrait(PG_ID) xysize (180,180)
            vbox:
                spacing 6
                xsize 920
                text "[pg_name] / 你的手牌" style 'pg_text' size 24
                use pg_hand_cards(72,100,920)
                $ sp_name = me['special'] or '已消耗'
                text "特殊卡：[sp_name]" style 'pg_small'
                if me['special']:
                    text PG_SPECIALS[me['special']] style 'pg_small' size 18

screen pg_partner(peers):
    modal True
    add Solid('#101820')
    use pg_header('回合交谈')
    frame:
        style 'pg_panel'
        xalign .5 ypos 190 xsize 1300 ysize 770
        vbox:
            spacing 20
            text "使用你的主动交谈机会" style 'pg_title'
            textbutton "本回合不主动交谈" style 'pg_button' action Return('skip')
            text "选择对象后，可以询问对方、主动透露，或打听同场第三人的牌；仅消耗你的主动机会，旁人也能听见。" style 'pg_small'
            viewport:
                mousewheel True
                scrollbars 'vertical'
                ysize 510
                vbox:
                    spacing 14
                    for pid in peers:
                        $ p = hg_players[pid]
                        button:
                            id ('pg_partner_'+str(pid))
                            style 'pg_button'
                            xfill True
                            action Return(pid)
                            hbox:
                                spacing 26
                                add pg_portrait(pid) xysize (128,128)
                                vbox:
                                    text p['name'] style 'pg_text'
                                    text p['opening'] style 'pg_small'

screen pg_talk_role():
    modal True
    add Solid('#101820')
    use pg_header('你如何开口？')
    frame:
        style 'pg_panel'
        xalign .5 yalign .5 xsize 1100
        vbox:
            spacing 26
            text '这次交谈，你想了解什么？' style 'pg_title'
            text '只消耗发起者的主动机会；被询问或听别人透露，不影响自己的机会。' style 'pg_small'
            textbutton '询问对方的牌' style 'pg_button' action Return('ask')
            textbutton '主动透露自己的牌' style 'pg_button' action Return('answer')
            textbutton '打听别人的牌' id 'pg_talk_gossip' style 'pg_button' sensitive bool(pg_gossip_subjects(pg_actor,pg_target)) action Return('gossip')
            if not pg_gossip_subjects(pg_actor,pg_target):
                text '当前场景没有可打听的第三人。' style 'pg_small'

screen pg_report_choice():
    modal True
    add Solid('#101820')
    use pg_header('你准备说什么？')
    frame:
        style 'pg_panel'
        xalign .5 yalign .55 xsize 1300 ysize 780
        hbox:
            spacing 35
            add pg_portrait(PG_ID) xysize (300,300)
            vbox:
                spacing 14
                text "报出一张普通牌的点数" style 'pg_title'
                use pg_hand_cards(66,92,850)
                if pg_phase == '决斗前交涉':
                    text "说真话：随机披露自己的一张牌。\n撒谎：选择手中没有的点数，本次交涉不扣分。\n所有同场景的人都可能听见。" style 'pg_small'
                else:
                    $ truth_delta = hg_report_score(pg_you(),hg_players[pg_listener])
                    $ lie_delta = hg_report_score(pg_you(),hg_players[pg_listener],True)
                    $ truth_status = '本次加5分' if truth_delta else '对该对象已加过分，本次不加分'
                    $ lie_status = '本次扣5分' if lie_delta else '对该对象已扣过分，本次不扣分'
                    text "说真话：[truth_status]；撒谎：[lie_status]。\n整局对同一人，真话加分、谎话扣分各限一次，分别计算。\n所有同场景的人都可能听见，旁听不触发额外加扣分。" style 'pg_small'
                textbutton "说真话（随机一张）" style 'pg_button' action Return('truth')
                text "或者报一个假点数：" style 'pg_small'
                vpgrid:
                    cols 6
                    spacing 10
                    ysize 210
                    mousewheel True
                    for value in range(2,15):
                        if value not in pg_you()['hand']:
                            textbutton pg_rank(value) id ('pg_lie_'+str(value)) style 'pg_button' action Return(value)

screen pg_accept(pid):
    modal True
    add Solid('#101820')
    use pg_header('接受，还是拒绝？')
    $ p = hg_players[pid]
    frame:
        style 'pg_panel'
        xalign .5 yalign .55 xsize 1250 ysize 600
        hbox:
            spacing 40
            add pg_portrait(pid) xysize (340,340)
            vbox:
                spacing 26
                text "[p['name']] 向你挑战" style 'pg_title'
                text p['opening'] style 'pg_text'
                $ n = len(p['hand'])
                text "对方手牌 [n] 张；剩余强制机会 [p['force']] 次。" style 'pg_small'
                text "普通决斗：胜+20 / 负-10 / 平0。\n被强制挑战也按此结算，没有额外扣分。" style 'pg_small'
                textbutton "同意普通决斗" style 'pg_button' action Return(True)
                textbutton "拒绝挑战" style 'pg_button' action Return(False)

screen pg_force_choice():
    modal True
    add Solid('#101820')
    use pg_header('对方拒绝了')
    frame:
        style 'pg_panel'
        xalign .5 yalign .5 xsize 1150
        vbox:
            spacing 28
            text "是否消耗一次强制机会？" style 'pg_title'
            text "强制获胜共+30；你失败-10、平局0。\n对方胜+20、负-10、平0，没有额外扣分。取消不会消耗主行动。" style 'pg_text'
            textbutton "使用强制机会" style 'pg_button' action Return(True)
            textbutton "取消挑战" style 'pg_button' action Return(False)

screen pg_card_choice(pid):
    modal True
    add Solid('#101820')
    use pg_header('第一步 / 扣下普通牌')
    $ p = hg_players[pid]
    frame:
        style 'pg_panel'
        xalign .5 ypos 190 xsize 1500 ysize 760
        vbox:
            spacing 25
            hbox:
                spacing 35
                add pg_portrait(pid) xysize (220,220)
                vbox:
                    spacing 16
                    text "对手：[p['name']]" style 'pg_title'
                    text ("双方独立锁定，全部决定后一起翻牌。" if mp_is_active() else "对手已锁定自己的选择，你看不到牌面。") style 'pg_small'
                    $ info = pg_you()['info'].get(pid)
                    if info:
                        $ report = pg_rank(info[0])
                        text "你听过的报牌：[report]（第[info[2]]回合，未经证实）" style 'pg_text'
                    else:
                        text "你没有对方的报牌情报。" style 'pg_text'
            text "选择普通牌后，再选择是否使用特殊卡。" style 'pg_text'
            viewport:
                mousewheel 'horizontal'
                scrollbars 'horizontal'
                ysize 190
                hbox:
                    spacing 18
                    for card in sorted(pg_you()['hand'], key=hg_card_sort_key):
                        button:
                            id ('pg_card_'+str(card)+'_'+str(getattr(card,'suit','unknown'))+'_'+str(getattr(card,'copy_id',0)))
                            background Solid('#253541')
                            hover_background Solid('#d7b975')
                            padding (4,4)
                            action Return(card)
                            use pg_playing_card(card,112,156)
            text "普通牌结算后弃置；使用保留卡可留下自己的普通牌。A=14，J=11，Q=12，K=13。" style 'pg_small'

screen pg_special_choice():
    modal True
    add Solid('#101820')
    use pg_header('第二步 / 特殊卡')
    frame:
        style 'pg_panel'
        xalign .5 yalign .5 xsize 1200
        vbox:
            spacing 28
            text "普通牌已扣好，尚未翻开。" style 'pg_title'
            $ sp = pg_you()['special']
            text "你的特殊卡：[sp]" style 'pg_text'
            text PG_SPECIALS[sp] style 'pg_text'
            text "特殊卡使用后消耗；保留卡只保护自己的普通牌，两张小牌效果不抵消。" style 'pg_small'
            textbutton "使用特殊卡，一起翻开" style 'pg_button' action Return(sp)
            textbutton "保留特殊卡，一起翻开" style 'pg_button' action Return('keep')

screen pg_info(tab='intel', called=False):
    modal True
    zorder 150
    default selected = tab
    add Solid('#101820f8')
    frame:
        style 'pg_panel'
        xpos 70 ypos 65 xsize 1780 ysize 950
        vbox:
            spacing 20
            hbox:
                spacing 22
                textbutton "情报" style 'pg_button' action SetScreenVariable('selected','intel')
                textbutton "名册" style 'pg_button' action SetScreenVariable('selected','roster')
                textbutton "公布榜单" style 'pg_button' action SetScreenVariable('selected','ranking')
                textbutton "规则" style 'pg_button' action SetScreenVariable('selected','rules')
                textbutton "对话记录" style 'pg_button' action SetScreenVariable('selected','log')
                textbutton "关闭" style 'pg_button' action (Return() if called else Hide('pg_info'))
            viewport:
                mousewheel True
                scrollbars 'vertical'
                ysize 790
                vbox:
                    spacing 18
                    if selected=='intel':
                        text "听到的不等于事实" style 'pg_title'
                        text "只记录你亲耳听到或偷听的报牌，不显示真实牌面或撒谎标记。" style 'pg_small'
                        for pid, report in pg_you()['info'].items():
                            $ p = hg_players[pid]
                            $ point = pg_rank(report[0])
                            text "[p['name']]：报过 [point]，当时手牌 [report[1]] 张，第 [report[2]] 回合。" style 'pg_text'
                        for pid, rumor in pg_you().get('rumors', {}).items():
                            $ person = hg_players[pid]
                            $ source = hg_players[rumor['source']]['name']
                            $ point = pg_rank(rumor['value'])
                            text "[person['name']]：据[source]转述有 [point]，第[rumor['round']]回合听到，原消息第[rumor['heard_round']]回合（未经证实）。" style 'pg_text'
                        if not pg_you()['info'] and not pg_you().get('rumors'):
                            text "暂时没有情报。" style 'pg_text'
                    elif selected=='roster':
                        text ("公开名册 / 真人与NPC" if mp_is_active() else "公开名册 / 25名NPC与你") style 'pg_title'
                        text "公开手牌数量与各区域人数；其他选手的实时积分、异地具体身份位置、牌面与特殊卡不公开。积分只在公布榜单时披露。" style 'pg_small'
                        for p in hg_players:
                            hbox:
                                spacing 25
                                add pg_portrait(p['id']) xysize (110,110)
                                vbox:
                                    $ count = len(p['hand'])
                                    $ where = '与你同场' if pg_visible(p) else '位置未知'
                                    $ control = ' / 真人' if p.get('human',False) else ''
                                    text "[p['name']] / [where][control]" style 'pg_text'
                                    text ("手牌 {} 张 / 积分 {}".format(count,p['score']) if p['id']==PG_ID else "手牌 {} 张 / 积分保密".format(count)) style 'pg_small'
                    elif selected=='ranking':
                        text "第5、10回合公布的历史快照，不是实时积分" style 'pg_title'
                        if not pg_announced:
                            text "尚未公布积分榜。" style 'pg_text'
                        for row in sorted(pg_announced,key=lambda r:r['score'],reverse=True):
                            $ shown_rank = 1 + sum(r['score'] > row['score'] for r in pg_announced)
                            text "第[shown_rank]名 [row['name']] / 积分[row['score']] / 第[row['round']]回合快照" style 'pg_text'
                    elif selected=='rules':
                        text "第一关 / 个人策略战" style 'pg_title'
                        text "26人 / 13场景 / 12回合 / 前16名存活。两副无王牌，A=14。" style 'pg_text'
                        text "每回合按积分排序：搜1张、沿通道移动1处、挑战1人或等待。" style 'pg_text'
                        text "所有人不得连续两回合搜寻卡牌；搜牌后必须间隔至少一回合。被动应战不会解除这个限制。" style 'pg_text'
                        text "同场且双方有牌才能决斗。每人每回合最多1战，两人整局最多1战。被动应战不占主行动。" style 'pg_text'
                        text "普通决斗双方同意；拒绝后可强制，每人2次。普通胜+20、负-10、平0。" style 'pg_text'
                        text "强制发起者胜+30、负-10、平0；被强制者胜+20、负-10、平0，没有额外扣分。" style 'pg_text'
                        text "双方先扣普通牌，再扣特殊卡，一起翻开。普通牌弃置（保留卡可免除自己的弃牌），特殊卡使用后消耗。" style 'pg_text'
                        text "特殊卡：保留本次普通牌 / 判定+5 / 小牌获胜。均为一次性，全程可用；两张小牌不抵消。" style 'pg_text'
                        text "每人每回合可主动发起一次交谈；被动接受不消耗机会，可多次参与。无对象则跳过。正式交谈中，整局向同一个人如实报牌最多加一次5分，谎报最多扣一次5分，两项分别计算。无牌不加分。" style 'pg_text'
                        text "按报牌者到直接交谈对象的方向分别记录：你对他说过，不影响他向你报牌的额度；换人另算，跨回合不重置。旁听者不计入额度。决斗前交涉与打听第三人均不加扣分，也不消耗这两项额度。" style 'pg_text'
                        text "交谈有三种选择：了解对方的牌、告诉对方自己的牌、打听别人的牌。打听仅可选择当前场景中除交谈双方之外的第三人；没有第三人时不可选。" style 'pg_text'
                        text "打听时，回答者可如实转述已知情报、撒谎或回答不知道，三种回答都不影响任何人的积分。没有已知情报不能如实转述；原消息可能不实或过时，转述不保证目标仍持有该牌。" style 'pg_text'
                        text "打听消耗发起者本回合的主动交谈机会，被询问者不消耗机会；同场可以偷听，转述情报单独标记为未经证实。" style 'pg_text'
                        text "最终分=积分+剩余手牌点数。前16存活；同分比积分，再同分抽签。" style 'pg_text'
                        text "NPC优先累计搜得3张是性格策略，不是对你的限制。" style 'pg_small'
                    else:
                        for turn, speaker, message in pg_public_log:
                            text "[turn] / [speaker]：[message]" style 'pg_small'

screen pg_results():
    modal True
    add Solid('#101820')
    $ my_rank = hg_final.index(PG_ID)+1
    $ won = my_rank<=16
    frame:
        style 'pg_panel'
        xpos 60 ypos 55 xsize 1800 ysize 970
        hbox:
            spacing 50
            vbox:
                xsize 520
                spacing 24
                add pg_portrait(PG_ID) xysize (420,420)
                text ('你活下来了。' if won else '你没能进入前16。') style 'pg_title'
                $ score = hg_total(pg_you())
                text "第 [my_rank] 名 / 最终总分 [score]" style 'pg_text'
                text "本轮结束。你的每次开口和出牌，都留下了结果。" style 'pg_small'
                textbutton "回到主菜单" style 'pg_button' action Return()
                textbutton "查看对话记录" style 'pg_button' action Show('pg_info',tab='log')
            viewport:
                mousewheel True
                scrollbars 'vertical'
                xsize 1130 ysize 880
                vbox:
                    spacing 14
                    text "最终排名" style 'pg_title'
                    for index,pid in enumerate(hg_final):
                        $ p = hg_players[pid]
                        $ final_score = hg_total(p)
                        $ label = '存活' if index<16 else '淘汰'
                        $ rank = index+1
                        hbox:
                            spacing 24
                            add pg_portrait(pid) xysize (76,76)
                            vbox:
                                text "[rank] / [p['name']] / [label]" style 'pg_text'
                                text "总分 [final_score] / 积分 [p['score']]" style 'pg_small'
