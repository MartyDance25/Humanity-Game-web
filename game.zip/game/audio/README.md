# Strategy tension music

Track: Ticking Shadow Card Table
Created with Meowa game-assets music demo, 2026-11-18.
Job: job_c954f3ecd91c4352806165a3ba1096bb
Runtime file: strategy_tension.mp3
Short instrumental preview, approximately 31 seconds; repeated by Ren’Py.
Creative direction: tense psychological card survival, low synth pulses, staccato strings, clock ticks, restrained percussion, no vocals.
Playback: starts before host rules, music channel, 2 second fade-in, track volume 0.45. Settings music slider remains effective. Stops after leaving results.
The source manifest is stored in simulation/music_loop_20261118.
