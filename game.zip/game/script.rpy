define host = Character("主持人", image="host", voice_tag="host")
image side host:
    "images/主持人.png"
    zoom 0.25

label start:
    jump pg_begin

label hg_rules:
   
    voice "audio/voice/host/rules_01.mp3"
    host "各位，欢迎来到第一关——个人策略战。请仔细听接下来的规则，这关乎到你们能否活着离开。"
    voice "audio/voice/host/rules_02.mp3"
    host "在场一共24人。这一关进行12个回合，结束时，只有排名前16的人可以存活。剩下的八位..."
    voice "audio/voice/host/rules_03.mp3"
    host "将被处决。"
    voice "audio/voice/host/rules_04.mp3"
    host "这所废弃学校分为14个区域。外围8个出生点，地图上标为紫色，每处随机安排3人，各藏6张牌。其他区域，分别藏8-10张牌，分配位置随机。总共104张，是去掉大小王的两副牌。"
    voice "audio/voice/host/rules_05.mp3"
    host "卡牌的花色不重要，只看点数，2到10照常计算，J是11，Q是12，K是13，A是14。"
    voice "audio/voice/host/rules_06.mp3"
    host "每回合开始，我会按积分从高到低安排你们行动。同分的人，顺序随机。这里只看积分，手牌不算。"
    voice "audio/voice/host/rules_07.mp3"
    host "轮到你时，可以从以下三个行动中选择一个执行：在场景里搜寻一张牌；移动到一个相邻区域；或者向同场的人发起决斗。不能连续两回合搜牌。"
    voice "audio/voice/host/rules_08.mp3"
    host "每回合，按积分顺序轮流选择并执行主行动。行动完成后，可以和同一区域的人交谈。每人每回合都有一次主动发起交谈的机会，可以询问，也可以主动透露。同一回合，你可以接受多个人的交谈。"
    voice "audio/voice/host/rules_09.mp3"
    host "交谈时，你可以询问对方，也可以主动透露自己的牌。说真话时，选一张手里的普通牌，说出它的点数。说假话时，报一个手中没有的点数，积分不变。没有牌时不能报牌。"
    voice "audio/voice/host/rules_10.mp3"
    host "正式交谈时，整局向同一个人如实报牌，最多拿一次5分。换个对象，可以再拿一次。"
    voice "audio/voice/host/rules_11.mp3"
    host "同一区域的其他人也能听见这些话，偷听不消耗交谈机会。"
    voice "audio/voice/host/rules_12.mp3"
    host "交谈还有第三种选择：打听别人的牌。你可以向对方打听当前区域内另一人的牌，只能选同场景的其他人。回答真假都不加分，也不扣分"
    voice "audio/voice/host/rules_13.mp3"
    host "接下来介绍一下决斗，你和对方必须在同一区域，而且双方手里都得有普通牌。空手的人不能主动挑战，也不能被别人挑战。"
    voice "audio/voice/host/rules_14.mp3"
    host "每个人每回合最多参加一场决斗，不论你是挑战者，还是被挑战者。被动应战不会花掉你的主行动。"
    voice "audio/voice/host/rules_15.mp3"
    host "在真正出牌之前，你们还会有一次交涉的机会，双方各报一次牌。这次交涉不计分。"
    voice "audio/voice/host/rules_16.mp3"
    host "普通决斗需要双方同意。如果对方不同意，可以使用强制战斗。"
    voice "audio/voice/host/rules_17.mp3"
    host "每个人都有两次强制战斗机会，如果使用，对方必须应战。不过，所有限制仍然有效。"
    voice "audio/voice/host/rules_18.mp3"
    host "普通决斗的奖惩很简单：赢的人加20分，输的人扣10分，平局双方都不加不扣。主动发起强制战斗的人，如果获胜，再额外拿10分。"
    voice "audio/voice/host/rules_19.mp3"
    host "出牌时，双方先各选一张普通牌，牌面朝下扣住；然后再决定是否使用特殊卡，也扣着放下。之后一起翻开按点数大小决定胜负。无论输赢，打出的普通牌通常都要弃掉，除非使用接下来介绍的保留卡。"
    voice "audio/voice/host/rules_20.mp3"
    host "现在讲讲特殊卡。每个人整局只有一次使用机会。你可以在决斗时，从接下来的三种效果中任选一种使用。"
    voice "audio/voice/host/rules_21.mp3"
    host "第一种，保留：这一场你打出的普通牌不会弃掉。"
    voice "audio/voice/host/rules_22.mp3"
    host "第二种，加5：你这次出牌的判定点数加5。"
    voice "audio/voice/host/rules_23.mp3"
    host "第三种，小牌：这一场改为点数小的人赢。"
    voice "audio/voice/host/rules_24.mp3"
    host "三种效果共用这一次机会。选了任何一种，整张特殊卡就消耗了。"
    voice "audio/voice/host/rules_25.mp3"
    host "第5和第10回合结束，我会公布积分排名，同积分并列。手里的牌不计入这两次榜单。"
    voice "audio/voice/host/rules_26.mp3"
    host "第12回合结束，积分与剩余手牌点数相加为最终总分。总分相同，积分更高的人排在前面；如果连积分也一样，就抽签决定。只有前16名能活下来。"
    voice "audio/voice/host/rules_27.mp3"
    host "好了，规则讲完了。"
    voice "audio/voice/host/rules_28.mp3"
    host "现在，游戏开始！"
    return

label hg_observe:
    menu:
        "观察下一回合（已完成 [hg_round] / 12）" if hg_round < 12:
            $ hg_lines = hg_step()
            $ hg_line_index = 0
            while hg_line_index < len(hg_lines):
                $ hg_speaker, hg_text = hg_lines[hg_line_index]
                $ hg_say_line(hg_speaker, hg_text)
                $ hg_line_index += 1
            jump hg_observe
        "查看24名玩家状态":
            call screen hg_roster
            jump hg_observe
        "查看规则":
            call hg_rules
            jump hg_observe
        "查看最终结果" if hg_round == 12:
            $ hg_lines = hg_finish()
            $ hg_line_index = 0
            while hg_line_index < len(hg_lines):
                $ hg_speaker, hg_text = hg_lines[hg_line_index]
                $ hg_say_line(hg_speaker, hg_text)
                $ hg_line_index += 1
            return
        "结束观察":
            return
