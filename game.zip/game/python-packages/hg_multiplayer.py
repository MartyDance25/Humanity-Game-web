"""LAN transport and host-authoritative play. No Ren'Py state in socket threads."""
import json
import queue
import secrets
import socket
import threading
import time
import types

PROTOCOL = 'humanity-lan-6-talk-scoring'
DEFAULT_PORT = 28426
MAX_PACKET = 262144
runtime = None


def wire(value):
    if hasattr(value, 'suit'):
        return [int(value), value.suit, value.copy_id]
    if isinstance(value, (list, tuple)):
        return [wire(v) for v in value]
    if isinstance(value, dict):
        return {str(k): wire(v) for k, v in value.items()}
    return value


def exact(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'))


class Peer:
    def __init__(self, sock, peer_id, events):
        self.sock, self.id, self.events = sock, peer_id, events
        self.outbox = queue.Queue(128)
        self.closed = threading.Event()
        self.last_received = time.monotonic()
        sock.settimeout(2)
        threading.Thread(target=self.read, daemon=True).start()
        threading.Thread(target=self.write, daemon=True).start()

    def send(self, message):
        if not self.closed.is_set():
            try:
                self.outbox.put_nowait(message)
            except queue.Full:
                self.close()

    def read(self):
        buffer = b''
        try:
            while not self.closed.is_set():
                try:
                    chunk = self.sock.recv(16384)
                except socket.timeout:
                    continue
                if not chunk:
                    break
                self.last_received = time.monotonic()
                buffer += chunk
                while b'\n' in buffer:
                    line, buffer = buffer.split(b'\n', 1)
                    if len(line) > MAX_PACKET:
                        raise ValueError('Packet too large')
                    packet = json.loads(line.decode('utf-8'))
                    if not isinstance(packet, dict):
                        raise ValueError('Expected object')
                    self.events.put_nowait(('packet', self.id, packet))
                if len(buffer) > MAX_PACKET:
                    raise ValueError('Packet too large')
        except (OSError, ValueError, queue.Full):
            pass
        finally:
            self.close()

    def write(self):
        try:
            while not self.closed.is_set():
                try:
                    message = self.outbox.get(timeout=.5)
                except queue.Empty:
                    continue
                data = (exact(message) + '\n').encode('utf-8')
                if len(data) > MAX_PACKET:
                    raise ValueError('Packet too large')
                self.sock.sendall(data)
        except (OSError, ValueError):
            self.close()

    def close(self):
        if not self.closed.is_set():
            self.closed.set()
            try:
                self.sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            self.sock.close()
            try:
                self.events.put_nowait(('disconnect', self.id, None))
            except queue.Full:
                pass


class Engine:
    def __init__(self, store, seats):
        # Clone rule-function globals so the host's UI projection cannot mutate
        # authoritative hands, scores, RNG decisions, or another player's input.
        self.env = dict(store)
        for name, fn in store.items():
            if name.startswith(('hg_', 'pg_')) and isinstance(fn, types.FunctionType):
                self.env[name] = types.FunctionType(fn.__code__, self.env, fn.__name__, fn.__defaults__, fn.__closure__)
        self.env.update(PG_ID=-1, pg_announced=[], pg_fought=[], pg_queue=[], pg_planned_action=None)
        self.call('hg_reset')
        self.call('hg_sync_names')
        self.humans = set(seats)
        for pid in seats:
            self.players[pid]['human'] = True
        self.logs = {pid: [] for pid in seats}
        self.pending, self.answers = {}, {}
        self.sequence = 0
        self.finished = False
        self.phase = '准备开局'
        self.flow = self.play()
        self.advance()

    @property
    def players(self):
        return self.env['hg_players']

    def call(self, name, *args, **kwargs):
        return self.env[name](*args, **kwargs)

    def emit(self, lines, room=None, only=None):
        recipients = self.humans if only is None else set(only)
        for pid in recipients:
            if room is None or self.players[pid]['room'] == room:
                for speaker, message in lines:
                    self.logs[pid].append([self.env['hg_round'], speaker or '记录', message])
                self.logs[pid] = self.logs[pid][-180:]

    def spec(self, pid, kind, options, **context):
        self.sequence += 1
        return dict(id=self.sequence, pid=pid, kind=kind, options=wire(options), context=context)

    def ask(self, pid, kind, options, **context):
        replies = yield [self.spec(pid, kind, options, **context)]
        return replies[pid]

    def advance(self, replies=None):
        try:
            specs = next(self.flow) if replies is None else self.flow.send(replies)
            self.pending = {s['pid']: s for s in specs}
            self.answers = {}
        except StopIteration:
            self.pending = {}
            self.finished = True
            self.phase = '最终结果'

    def answer(self, pid, request_id, value):
        prompt = self.pending.get(pid)
        if type(request_id) is not int or not prompt or prompt['id'] != request_id or pid in self.answers:
            return False
        if not isinstance(value, (str, int, list)):
            return False
        if isinstance(value, list) and (len(value) > 3 or any(type(v) not in (str, int, type(None)) for v in value)):
            return False
        if exact(value) not in {exact(v) for v in prompt['options']}:
            return False
        self.answers[pid] = value
        if len(self.answers) == len(self.pending):
            self.advance(dict(self.answers))
        return True

    def report(self, reporter, listener, phase):
        p, q = self.players[reporter], self.players[listener]
        declared = None
        if reporter in self.humans and p['hand']:
            # Owned ranks are truthful reports; all other ranks are lies.
            # The host derives truth from its own hand state, never a client flag.
            options = list(range(2,15))
            declared = yield from self.ask(reporter, 'report', options,
                reporter=reporter, listener=listener, phase=phase)
        lines = []
        self.call('hg_report', p, q, lines, phase, declared=declared)
        self.emit(lines, room=p['room'])

    def gossip(self, actor, target, subject=None):
        subjects = self.call('pg_gossip_subjects', actor, target)
        if not subjects:
            return
        if subject is None:
            subject = yield from self.ask(actor, 'gossip_target', subjects, actor=actor, target=target)
        p, q = self.players[actor], self.players[target]
        self.emit([(p['name'], '{}，你知道{}的牌吗？'.format(q['name'], self.players[subject]['name']))], room=p['room'])
        if target in self.humans:
            options = ['unknown'] + self.call('pg_gossip_lie_values', q, subject)
            if self.call('pg_known_report', q, subject):
                options.append('truth')
            reply = yield from self.ask(target, 'gossip_reply', options, actor=actor, target=target, subject=subject)
        else:
            reply = self.call('pg_npc_gossip_reply', q, subject)
        self.emit(self.call('pg_gossip_report', actor, target, subject, reply), room=p['room'])

    def talk(self, actor):
        p = self.players[actor]
        peers = [q['id'] for q in self.players if q is not p and q['room'] == p['room']]
        if not peers:
            return
        subject = None
        if actor in self.humans:
            target = yield from self.ask(actor, 'partner', ['skip'] + peers, actor=actor, peers=peers)
            if target == 'skip':
                return
            self.call('pg_pair', actor, target)
            options = ['ask', 'answer']
            if self.call('pg_gossip_subjects', actor, target):
                options.append('gossip')
            role = yield from self.ask(actor, 'role', options, actor=actor, target=target)
        else:
            plan = self.call('pg_npc_talk_plan', p, [self.players[pid] for pid in peers])
            if plan is None:
                return
            target, role, subject = plan
            self.call('pg_pair', actor, target)
        if role == 'gossip':
            yield from self.gossip(actor, target, subject)
        else:
            if actor not in self.humans:
                self.emit([(p['name'], self.call('hg_talk_opening', p, self.players[target], role))], room=p['room'])
            reporter, listener = (actor, target) if role in ('answer', 'reveal') else (target, actor)
            yield from self.report(reporter, listener, '回合交谈')

    def duel(self, actor, target):
        p, q = self.players[actor], self.players[target]
        room = p['room']
        self.emit([(p['name'], '{}，和我打一场。'.format(q['name']))], room=room)
        yield from self.report(target, actor, '决斗前交涉')
        yield from self.report(actor, target, '决斗前交涉')
        consent = (yield from self.ask(target, 'accept', [True, False], actor=actor, target=target)) if target in self.humans else self.call('hg_accept', q, p)
        self.emit([(q['name'], '我同意。' if consent else '我拒绝。')], room=room)
        forced = False
        if not consent and p['force'] > 0:
            forced = (yield from self.ask(actor, 'force', [True, False], actor=actor, target=target)) if actor in self.humans else self.call('hg_force_worthwhile', p, q)
            if forced:
                p['force'] -= 1
                self.emit([(p['name'], '我使用强制机会。这一场，不能拒绝。')], room=room)
        if not consent and not forced:
            self.emit([(None, '挑战取消，没有消耗主行动。')], room=room)
            return False
        choices = {pid: self.call('hg_commit', self.players[pid], self.players[target if pid == actor else actor])
            for pid in (actor, target) if pid not in self.humans}
        humans = [pid for pid in (actor, target) if pid in self.humans]
        if humans:
            # Both humans lock independently. No chosen card is broadcast before reveal.
            replies = yield [self.spec(pid, 'card', self.players[pid]['hand'],
                actor=actor, target=target, opponent=target if pid == actor else actor) for pid in humans]
            for pid in humans:
                selected = next(card for card in self.players[pid]['hand'] if wire(card) == replies[pid])
                choices[pid] = (selected, None)
            special_users = [pid for pid in humans if self.players[pid]['special']]
            if special_users:
                replies = yield [self.spec(pid, 'special', ['keep'] + list(self.call('hg_special_options',self.players[pid])),
                    actor=actor, target=target) for pid in special_users]
                for pid in special_users:
                    choices[pid] = (choices[pid][0], None if replies[pid] == 'keep' else replies[pid])
        lines = []
        self.call('hg_duel', p, q, forced, lines, choices[actor], choices[target])
        self.env['pg_fought'].extend((actor, target))
        self.call('pg_finish_action', actor)
        self.emit(lines, room=room)
        return True

    def action(self, actor):
        p = self.players[actor]
        while True:
            if actor in self.humans:
                options = [['wait', None]]
                if self.call('hg_can_search', p):
                    options.append(['search', None])
                options += [['move', room] for room in self.env['HG_MAP'][p['room']]]
                options += [['challenge', q['id']] for q in self.call('pg_targets', p)]
                kind, dest = yield from self.ask(actor, 'action', options, actor=actor)
            else:
                kind, dest = self.call('pg_ai_action', actor)
            if kind == 'challenge':
                if (yield from self.duel(actor, dest)):
                    return
                if actor in self.humans:
                    continue
                kind, dest = 'move', self.env['renpy'].random.choice(self.env['HG_MAP'][p['room']])
            old = p['room']
            self.call('pg_do_action', actor, kind, dest)
            if kind == 'search':
                self.emit([(None, '你搜到了{}。'.format(self.call('hg_card_name', p['hand'][-1])))], only=[actor] if actor in self.humans else [])
                self.emit([(None, '{}搜到一张牌，现在有{}张。'.format(p['name'], len(p['hand'])))], room=old,
                    only=self.humans - {actor})
            elif kind == 'move':
                text = '{}从{}移往{}。'.format(p['name'], self.env['PG_ROOMS'][old], self.env['PG_ROOMS'][dest])
                observers = {pid for pid in self.humans if self.players[pid]['room'] in (old, dest)}
                self.emit([(None, text)], only=observers)
            else:
                self.emit([(None, '{}选择等待。'.format(p['name']))], room=old)
            return

    def play(self):
        for pid in self.humans:
            p = self.players[pid]
            self.emit([(None, '你扮演{}，在{}醒来。你有1次特殊卡机会，可从保留、加5、小牌中任选一种效果。'.format(p['name'], self.env['PG_ROOMS'][p['room']]))], only=[pid])
        while self.env['hg_round'] < 12:
            self.phase = '主行动'
            self.emit(self.call('pg_begin_round'))
            order = [e['actor'] for e in self.env['pg_queue'] if e['kind'] == 'action']
            for actor in order:
                yield from self.action(actor)
            self.phase = '回合交谈'
            for actor in order:
                yield from self.talk(actor)
            self.call('pg_close_round')
            self.emit([(None, '第{}回合结束。'.format(self.env['hg_round']))])
            if self.env['hg_round'] in (5, 10):
                self.emit([('主持人', '本回合积分榜已公布，可在情报面板查看。')])
        self.emit(self.call('hg_finish'))

    def snapshot(self, pid):
        me = self.players[pid]
        players = []
        for p in self.players:
            own = p['id'] == pid
            row = dict(id=p['id'], name=p['name'], opening=p['opening'], family=p['family'],
                human=p.get('human', False), hand=wire(p['hand']) if own else [0] * len(p['hand']),
                score=p['score'] if own or self.finished else 0,
                room=p['room'] if own or p['room'] == me['room'] else 0,
                force=p['force'], special=p['special'] if own else None,
                info=wire(p['info']) if own else {}, rumors=wire(p.get('rumors', {})) if own else {})
            if self.finished:
                row['final_total'] = self.call('hg_total', p)
            players.append(row)
        history = [dict(e) for e in self.env['hg_history']
            if (e['phase'] == '回合交谈' and e['speaker'] == pid)
            or (e['phase'] == '主行动' and e['actor'] == pid)]
        prompt = self.pending.get(pid) if pid not in self.answers else None
        return dict(phase='result' if self.finished else 'game', pid=pid, players=players,
            rooms={str(k): len(v) for k, v in self.env['hg_rooms'].items()},
            occupants={str(k): sum(p['room'] == k for p in self.players) for k in self.env['HG_MAP']},
            round=self.env['hg_round'], stage=self.phase, logs=self.logs[pid], history=history,
            pairs=[list(pair) for pair in self.env['hg_pairs'] if pid in pair],
            fought=[p for p in self.env['pg_fought'] if p == pid or self.players[p]['room'] == me['room']],
            ranking=wire(self.env['pg_announced']), final=self.env['hg_final'], prompt=prompt)


class Room:
    def __init__(self, host, port, code, store=None):
        self.hosting = host is None
        self.host, self.port, self.code = host, port, code.upper().strip()
        self.store = store
        self.events = queue.Queue(2048)
        self.peers, self.members = {}, {}
        self.tokens = {}
        self.engine = None
        self.view = dict(phase='lobby', members=[], status='正在连接房主…')
        self.closed = False
        self.peer = None
        self.token = None
        self.connecting = False
        self.last_connect = 0
        self.status = ''
        self.notice = ''
        self.generation = 0
        self.last_ping = 0
        self.revision = 0
        self.listener = None
        if self.hosting:
            self.members['host'] = dict(key='host', role=None, connected=True, seat=None)
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                sock.bind(('0.0.0.0', port))
                sock.listen(24)
                sock.settimeout(.5)
            except Exception:
                sock.close()
                raise
            self.listener = sock
            threading.Thread(target=self.accept, daemon=True).start()
        else:
            self.connect()

    def accept(self):
        while not self.closed:
            try:
                sock, _ = self.listener.accept()
                if self.closed:
                    sock.close()
                else:
                    try:
                        self.events.put_nowait(('connect', secrets.token_hex(12), sock))
                    except queue.Full:
                        sock.close()
            except socket.timeout:
                continue
            except (OSError, queue.Full):
                break

    def connect(self):
        if self.closed or self.connecting:
            return
        self.connecting, self.last_connect = True, time.monotonic()
        def worker():
            try:
                sock = socket.create_connection((self.host, self.port), timeout=3)
                if self.closed:
                    sock.close()
                else:
                    self.events.put(('client_connect', 'server', sock))
            except OSError:
                self.events.put(('connection_error', '', None))
        threading.Thread(target=worker, daemon=True).start()

    def lobby(self):
        return dict(phase='lobby', members=[dict(m) for m in self.members.values()],
            code=self.code, status=self.status or '选择人物，或保留随机分配。由房主开始游戏。')

    def send_view(self):
        self.revision += 1
        if self.engine:
            disconnected = any(not m['connected'] for m in self.members.values())
            for key, member in self.members.items():
                view = self.engine.snapshot(member['seat'])
                if disconnected:
                    view['prompt'] = None
                view['status'] = '有玩家断线，已暂停，等待原玩家重连。' if disconnected else ('轮到你操作。' if view['prompt'] else '等待其他玩家操作…')
                self.deliver(key, view)
        else:
            view = self.lobby()
            for key in self.members:
                self.deliver(key, view)

    def deliver(self, key, view):
        if key == 'host':
            self.view = view
        else:
            peer = self.peers.get(key)
            if peer:
                peer.send(dict(type='view', view=view))

    def error(self, key, message):
        if key == 'host':
            self.status = message
            self.notice = message
        elif key in self.peers:
            self.peers[key].send(dict(type='error', message=message))

    def command(self, key, packet):
        member = self.members.get(key)
        if not member:
            return
        kind = packet.get('type')
        if kind == 'ping':
            self.peers[key].send(dict(type='pong'))
            return
        if kind == 'pong':
            return
        if kind == 'select' and not self.engine:
            role = packet.get('role')
            if role is not None and (type(role) is not int or not 0 <= role < 24):
                return
            if role is not None and any(m['role'] == role for k, m in self.members.items() if k != key):
                self.error(key, '该角色已被其他玩家选择，请换一个。')
                return
            member['role'] = role
            self.status = ''
        elif kind == 'answer' and self.engine:
            if any(not m['connected'] for m in self.members.values()):
                return
            if not self.engine.answer(member['seat'], packet.get('id'), packet.get('value')):
                self.error(key, '这个选择已失效或不符合规则，请按最新提示重新选择。')
        self.send_view()

    def start(self):
        if not self.hosting or self.engine:
            return
        if len(self.members) < 2 or any(not m['connected'] for m in self.members.values()):
            self.status = '至少需要两名已连接的玩家。'
            self.send_view()
            return
        taken = {m['role'] for m in self.members.values() if m['role'] is not None}
        available = [i for i in range(24) if i not in taken]
        secrets.SystemRandom().shuffle(available)
        for member in self.members.values():
            member['seat'] = member['role'] if member['role'] is not None else available.pop()
        self.engine = Engine(self.store, [m['seat'] for m in self.members.values()])
        self.send_view()

    def poll(self):
        changed = False
        for _ in range(150):
            try:
                kind, key, packet = self.events.get_nowait()
            except queue.Empty:
                break
            changed = True
            if kind == 'connect':
                if len(self.peers) >= 52:
                    packet.close()
                else:
                    self.peers[key] = Peer(packet, key, self.events)
            elif kind == 'client_connect':
                self.connecting = False
                if self.closed:
                    packet.close()
                    continue
                self.peer = Peer(packet, 'server', self.events)
                self.peer.send(dict(type='hello', protocol=PROTOCOL, code=self.code, token=self.token))
            elif kind == 'connection_error':
                self.connecting = False
                self.view['status'] = '连接失败，正在重试。请检查房主IP、端口、Tailscale与防火墙。'
            elif kind == 'disconnect':
                if self.hosting:
                    self.peers.pop(key, None)
                    if key in self.members:
                        if self.engine:
                            self.members[key]['connected'] = False
                        else:
                            self.members.pop(key)
                    self.send_view()
                else:
                    self.peer = None
                    self.view['prompt'] = None
                    self.view['status'] = '与房主断开，正在尝试重连，请保留此窗口。'
            elif kind == 'packet' and self.hosting:
                if key not in self.peers:
                    continue
                if key not in self.members:
                    if packet.get('type') != 'hello' or packet.get('protocol') != PROTOCOL or packet.get('code') != self.code:
                        self.peers[key].send(dict(type='error', message='房间码或游戏协议版本不匹配。'))
                        continue
                    old_key = self.tokens.get(packet.get('token')) if isinstance(packet.get('token'), str) else None
                    if old_key in self.members:
                        member = self.members.pop(old_key)
                        old_peer = self.peers.pop(old_key, None)
                        if old_peer:
                            old_peer.close()
                        member.update(key=key, connected=True)
                        self.members[key] = member
                        self.tokens[packet['token']] = key
                        token = packet['token']
                    elif self.engine or len(self.members) >= 24:
                        self.peers[key].send(dict(type='error', message='游戏已开始或房间已满，无法加入。'))
                        continue
                    else:
                        self.members[key] = dict(key=key, role=None, connected=True, seat=None)
                        token = secrets.token_hex(24)
                        self.tokens[token] = key
                    self.peers[key].send(dict(type='welcome', token=token, key=key))
                    self.send_view()
                else:
                    self.command(key, packet)
            elif kind == 'packet':
                if packet.get('type') == 'welcome':
                    self.token, self.key = packet['token'], packet['key']
                    self.generation += 1
                elif packet.get('type') == 'view' and isinstance(packet.get('view'), dict):
                    self.view = packet['view']
                elif packet.get('type') == 'error':
                    self.view['status'] = str(packet.get('message', '连接错误'))
                    self.notice = self.view['status']
                    # Explicit rejection needs user correction, not endless retries.
                    if not self.token:
                        self.last_connect = float('inf')
                elif packet.get('type') == 'ping' and self.peer:
                    self.peer.send(dict(type='pong'))
        now = time.monotonic()
        if now - self.last_ping >= 2:
            self.last_ping = now
            links = list(self.peers.values()) if self.hosting else ([self.peer] if self.peer else [])
            for peer in links:
                if now - peer.last_received > 16:
                    peer.close()
                elif not self.hosting or peer.id in self.members:
                    peer.send(dict(type='ping'))
        if not self.hosting and not self.closed and not self.connecting and self.peer is None and time.monotonic() - self.last_connect >= 3:
            self.connect()
        return changed

    def submit(self, packet):
        if self.hosting:
            self.command('host', packet)
        elif self.peer:
            self.peer.send(packet)

    def close(self):
        self.closed = True
        if self.listener:
            self.listener.close()
        for peer in list(self.peers.values()):
            peer.close()
        if self.peer:
            self.peer.close()
        while True:
            try:
                kind, _, value = self.events.get_nowait()
            except queue.Empty:
                break
            if kind in ('connect', 'client_connect'):
                value.close()
