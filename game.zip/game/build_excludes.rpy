# Local simulations, test fixtures and hosting workspaces are not game assets.
init python:
    build.classify("simulation/**", None)
    build.classify("tests/**", None)
    build.classify("web_publish/**", None)
    build.classify("web_host/**", None)
    build.classify("web_publish.tar.gz", None)
    build.classify("web_host_*.tar.gz", None)
    build.classify("game/gameplay_tests.rpy", None)
    build.classify("game/gameplay_tests.rpyc", None)
    build.classify("game/background_tests.rpy", None)
    build.classify("game/background_tests.rpyc", None)
