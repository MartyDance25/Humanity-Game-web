init python:
    # These announcements are shown through renpy.say instead of script dialogue.
    HG_HOST_ANNOUNCEMENT_VOICES = {
        '最终结果公布，前16名存活。': 'result',
        '当前积分排名公布。': 'observe_ranking',
    }
    for _host_round in range(1, 13):
        HG_HOST_ANNOUNCEMENT_VOICES[
            '第 {} / 12 回合。按积分顺序选择并执行主行动，行动结束后再进行回合交谈。'.format(_host_round)
        ] = 'round_{:02d}'.format(_host_round)
        HG_HOST_ANNOUNCEMENT_VOICES['第{}回合。'.format(_host_round)] = 'observe_{:02d}'.format(_host_round)

    for _host_round in (5, 10):
        HG_HOST_ANNOUNCEMENT_VOICES[
            '第{}回合积分榜已公布，可在情报面板查阅。'.format(_host_round)
        ] = 'ranking_{:02d}'.format(_host_round)
    del _host_round

    def hg_say_line(speaker, line):
        if speaker == '主持人':
            clip = HG_HOST_ANNOUNCEMENT_VOICES.get(line)
            if clip:
                voice('audio/voice/host/{}.mp3'.format(clip), tag='host')
        renpy.say(speaker, line)
