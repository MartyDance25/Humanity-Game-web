# Save/rollback-friendly mutable state; all randomness uses renpy.random.
default hg_players = []
default hg_rooms = {}
default hg_pairs = []
default hg_round = 0
default hg_history = []
default hg_final = []
default hg_lines = []
default hg_line_index = 0

init python:
    HG_PROFILES = [('随性客', '随机出牌型', 0.5, 0.5, 0.5, 0.5), ('赌徒', '随机出牌型', 0.85, 0.85, 0.35, 0.85), ('漫游者', '随机出牌型', 0.25, 0.45, 0.9, 0.4), ('机会主义者', '随机出牌型', 0.65, 0.55, 0.55, 0.65), ('猎手', '高频强攻型', 0.95, 0.8, 0.55, 0.85), ('狂战士', '高频强攻型', 1.0, 1.0, 0.25, 1.0), ('追击者', '高频强攻型', 0.9, 0.7, 0.9, 0.75), ('决斗家', '高频强攻型', 0.85, 0.9, 0.4, 0.7), ('强征者', '高频强攻型', 1.0, 0.65, 0.65, 0.9), ('守卫', '谨慎反击型', 0.1, 0.2, 0.2, 0.8), ('隐士', '谨慎反击型', 0.02, 0.05, 0.75, 0.95), ('谨慎者', '谨慎反击型', 0.2, 0.25, 0.45, 0.6), ('反击者', '谨慎反击型', 0.35, 0.6, 0.3, 0.95), ('囤积者', '保牌避战型', 0.03, 0.08, 0.3, 0.7), ('寻宝者', '保牌避战型', 0.1, 0.15, 0.95, 0.6), ('搬运工', '保牌避战型', 0.05, 0.1, 0.65, 0.45), ('收藏家', '保牌避战型', 0.15, 0.2, 0.45, 0.8), ('精算师', '估牌择战型', 0.75, 0.3, 0.6, 0.95), ('谋士', '估牌择战型', 0.65, 0.25, 0.75, 0.9), ('投机者', '估牌择战型', 0.9, 0.45, 0.85, 0.85), ('保本者', '估牌择战型', 0.35, 0.15, 0.35, 0.75), ('外交官', '情报择牌型', 0.3, 0.55, 0.6, 0.65), ('情报商', '情报择牌型', 0.55, 0.35, 0.8, 0.9), ('均衡者', '适度进攻型', 0.5, 0.45, 0.5, 0.7), ('冒险家', '适度进攻型', 0.75, 0.65, 0.85, 0.8), ('稳健者', '适度进攻型', 0.3, 0.3, 0.4, 0.65)]
    HG_MAP = {1: [2], 2: [1, 5, 6], 3: [7], 4: [5], 5: [2, 4, 8], 6: [2], 7: [3, 8, 9, 12], 8: [5, 7], 9: [7, 10, 11], 10: [9], 11: [9, 13], 12: [7], 13: [11]}
    HG_VOICES = [
        ('直率，没什么戒心', .02, '你问吧，我不会骗你的。说实话反而还能加分不是吗'),
        ('兴奋，爱赌但不擅长骗', .06, '来一把？我觉得运气在我这边！'),
        ('好奇，容易相信别人', .01, '欸，你的牌是不是很大？'),
        ('随性，想到什么说什么', .08, '行吧，我先说我的。'),
        ('冷硬，习惯施压', .20, '别想骗我，说实话。'),
        ('暴躁，不愿示弱', .12, '磨蹭什么！敢不敢打？'),
        ('执拗，紧盯目标', .22, '我一定会赢下这场比赛的'),
        ('骄傲，重视正面较量', .05, '来决斗吧，我不想浪费时间。这场游戏我势在必得。'),
        ('蛮横，把拒绝当挑衅', .30, '你觉得自己有得选？'),
        ('克制，先讲边界', .12, '我们先互不侵犯，好吗？'),
        ('寡言，隐瞒真实想法', .35, '我只想一个人待着。'),
        ('多疑，说话留有余地', .25, '先别急，让我想想。'),
        ('外柔内硬，不怕还手', .18, '别惹我，不然你会死得很惨'),
        ('讨好，用软话保护手牌', .65, '大家都不容易，我的牌也不小，要不换个人呗？'),
        ('热情，借闲聊转移注意', .50, '那边说不定更有意思，一起去看看吗？'),
        ('示弱，装作没有威胁', .70, '我哪是你的对手，放我一马吧。'),
        ('温和，善于包装谎言', .55, '这些牌留着多好，何必拼个你死我活？'),
        ('精确，用数字掩饰目的', .30, '以我的牌力，你胜不了我'),
        ('含蓄，话里常有试探', .45, '你确定你的牌比我大？'),
        ('油滑，喜欢引人下注', .55, '机会就这一次，要不要试试？'),
        ('保守，重视止损', .20, '我不想和你斗个两败俱伤。'),
        ('圆滑，给双方留台阶', .35, '我们可以合作，一起活下去'),
        ('精明，真假信息混着讲', .50, '你想不想知道他是什么牌？'),
        ('平和，进退有度', .15, '你想好了？都再考虑一下吧。'),
        ('爽快，愿意承担风险', .10, '有风险才有意思，来吧。'),
        ('沉稳，不轻易承诺', .12, '你可以问我，能说的我会说。'),
    ]
    HG_STYLE = {
        '随机出牌型': ('我手里有一张{v}。你可别打我。', '好呀，试试看！', '我有点害怕，这次不打行吗？'),
        '高频强攻型': ('我有{v}，自己掂量。', '来！别后悔。', '少来这套，我凭什么听你的？'),
        '谨慎反击型': ('我能告诉你的是{v}，别的先不谈。', '既然如此，我接下。', '风险不合适，我拒绝。'),
        '保牌避战型': ('我也就一张{v}，咱们别伤和气，好吗？', '那……你可别太狠。', '求你换个人吧，我帮你留意消息。'),
        '估牌择战型': ('我有{v}这个牌，有本事你就试试', '这次值得试，我同意。', '算了，跟你打不划算。'),
        '情报择牌型': ('我这张是{v}。信不信取决于你', '既然你这么说，那我就不客气了。', '何必现在翻脸？留个下次见面的余地。'),
        '适度进攻型': ('我这边有{v}，你怎么想？', '好，打一场。', '这回就算了吧。'),
    }

    def hg_reset():
        global hg_players, hg_rooms, hg_pairs, hg_round, hg_history, hg_final
        deck = [HGCard(rank, suit, copy_id) for copy_id in range(2)
            for suit in HG_SUITS for rank in range(2,15)]
        renpy.random.shuffle(deck)
        spots = list(range(1,14)) * 2
        renpy.random.shuffle(spots)
        hg_rooms = {i: deck[(i-1)*8:i*8] for i in range(1,14)}
        hg_players = []
        for i, profile in enumerate(HG_PROFILES):
            voice = HG_VOICES[i]
            hg_players.append(dict(id=i, name=profile[0], family=profile[1], aggression=profile[2],
                acceptance=profile[3], exploration=profile[4], willingness=profile[5],
                temperament=voice[0], lie_rate=voice[1], opening=voice[2],
                room=spots[i], hand=[], score=0, searched=0, force=2,
                special=renpy.random.choice(['保留','加5','小牌']), info={}, lies=0,
                battles=0, discarded=0, bonus=0, penalty=0))
        hg_pairs, hg_history, hg_final = [], [], []
        hg_round = 0

    def hg_total(p):
        return p.get('final_total',p['score'] + sum(p['hand']))

    def hg_can_search(p):
        last = p.get('last_search_round', -1)
        # Existing interactive saves already record main actions.
        last = max([last] + [e['round'] for e in hg_history
            if e.get('phase') == '主行动' and e.get('actor') == p['id']
            and e.get('action') == 'search'])
        return bool(hg_rooms[p['room']]) and last < hg_round - 1

    def hg_report_score(speaker, listener, lied=False, phase='回合交谈'):
        # Truth and lie limits are independent, per directed pair, for the whole game.
        # Old saves already record the direct listener and whether each report lied.
        if phase != '回合交谈' or not speaker['hand']:
            return 0
        used = any(e.get('phase') == '回合交谈'
            and e.get('speaker') == speaker['id'] and e.get('listener') == listener['id']
            and e.get('lied') == lied for e in hg_history)
        return 0 if used else (-5 if lied else 5)

    def hg_report(speaker, listener, lines, phase, declared=None):
        if not speaker['hand']:
            lines.append((speaker['name'], '我现在没有普通牌，没什么可报的。'))
            return
        actual = int(renpy.random.choice(speaker['hand']))
        options = [v for v in range(2,15) if v not in speaker['hand']]
        # Favor truth while it earns points or lying still incurs a penalty.
        rate=speaker['lie_rate']
        if phase=='回合交谈' and hg_report_score(speaker,listener) > hg_report_score(speaker,listener,True):
            risk=hg_talk_risk(speaker)
            rate *= (0 if risk<.25 else risk*(.55 if speaker['family']=='保牌避战型' else .18))
        lied = bool(options) and renpy.random.random() < rate
        value = (max(options) if speaker['family'] in ('高频强攻型','保牌避战型','谨慎反击型') else min(options) if speaker['family'] in ('估牌择战型','情报择牌型') else renpy.random.choice(options)) if lied else actual
        if declared is not None:
            value = actual if declared == 'truth' else int(declared)
            lied = value not in speaker['hand']
        # lies counts charged penalties for the scoring invariant, not all false reports.
        score_delta = hg_report_score(speaker,listener,lied,phase)
        speaker['score'] += score_delta
        if score_delta < 0:
            speaker['lies'] += 1
        elif score_delta > 0:
            speaker['truth_bonus'] = speaker.get('truth_bonus', 0) + score_delta
        lines.append((speaker['name'], HG_STYLE[speaker['family']][0].format(v=value)))
        listeners = [p for p in hg_players if p['room']==speaker['room'] and p is not speaker]
        for p in listeners:
            p['info'][speaker['id']] = (value, len(speaker['hand']), hg_round)
        hg_history.append(dict(round=hg_round, phase=phase, speaker=speaker['id'],
            listener=listener['id'], room=speaker['room'], reported=value, actual=actual,
            lied=lied, score_delta=score_delta,
            overheard_by=[p['id'] for p in listeners if p is not listener]))
        if len(listeners)>1:
            lines.append((None, '附近的人也听见了这句话。'))

    def hg_estimate(p,q):
        report = p['info'].get(q['id'])
        count = len(q['hand'])
        if not report or not count or report[1]!=count or hg_round-report[2]>2:
            return 8
        return (report[0]+8*(count-1))/count

    def hg_commit(p,q):
        low = p['special']=='小牌' and min(p['hand'])<=6
        if p['family']=='随机出牌型':
            card=renpy.random.choice(p['hand'])
        elif low:
            card=min(p['hand'])
        elif p['family'] in ('估牌择战型','情报择牌型','高频强攻型','适度进攻型'):
            winners=[v for v in p['hand'] if v>hg_estimate(p,q)]
            card=min(winners) if winners else min(p['hand'])
        else:
            card=max(p['hand'])
        use = ((p['special']=='小牌' and low) or
            (p['special']=='保留' and (card>=10 or hg_round>=10)) or
            (p['special']=='加5' and card<=hg_estimate(p,q)<card+5))
        return card, p['special'] if use and renpy.random.random()<p['willingness'] else None

    def hg_duel(p,q,forced,lines,choice_p=None,choice_q=None):
        # Commit both ordinary/special choices before any reveal or score mutation.
        a,sa=choice_p if choice_p is not None else hg_commit(p,q)
        b,sb=choice_q if choice_q is not None else hg_commit(q,p)
        assert a in p['hand'] and b in q['hand']
        assert sa is None or sa == p['special']
        assert sb is None or sb == q['special']
        lines.append((None, '双方扣下普通牌，再扣下特殊卡或选择不用。一起翻开——'))
        lines.append((None, '{}：{}，特殊卡{}；{}：{}，特殊卡{}。'.format(p['name'],hg_card_name(a),sa or '无',q['name'],hg_card_name(b),sb or '无')))
        av,bv=a+5*(sa=='加5'),b+5*(sb=='加5')
        low=sa=='小牌' or sb=='小牌'
        result=0 if av==bv else (1 if (av<bv if low else av>bv) else -1)
        for actor,card,special,outcome in ((p,a,sa,result),(q,b,sb,-result)):
            if special!='保留':
                hg_discard_card(actor,card)
                actor['discarded']+=1
            actor['battles']+=1
            delta=20 if outcome==1 else -10 if outcome==-1 else 0
            if forced and actor is p and outcome==1:
                delta+=10
                actor['bonus']+=10
            actor['score']+=delta
            if special: actor['special']=None
            lines.append((None, '{}本次积分{:+d}，{}。'.format(actor['name'],delta,'本次普通牌保留在手中，保留卡已消耗' if special=='保留' else '本次普通牌弃置')))
        hg_pairs.append(tuple(sorted((p['id'],q['id']))))
        hg_history.append(dict(round=hg_round,phase='决斗',initiator=p['id'],defender=q['id'],forced=forced,result=result))

    def hg_step():
        global hg_round
        if hg_round>=12: return [(None,'12回合已经结束。')]
        hg_round+=1
        lines=[('主持人','第{}回合。'.format(hg_round))]
        order=list(hg_players)
        renpy.random.shuffle(order)
        order.sort(key=lambda p:p['score'],reverse=True)
        communicated=set()
        fought=set()
        # Mandatory pairing phase: one conversation participation per person.
        for p in order:
            if p['id'] in communicated: continue
            peers=[q for q in order if q is not p and q['room']==p['room'] and q['id'] not in communicated]
            if not peers:
                lines.append((None,'{}本回合没有可配对的交谈对象。'.format(p['name'])))
                continue
            q=renpy.random.choice(peers)
            communicated.update((p['id'],q['id']))
            lines.append((p['name'],p['opening']))
            hg_report(q,p,lines,'回合交谈')
        for p in order:
            if p['searched']<3 and hg_can_search(p):
                p['hand'].append(hg_rooms[p['room']].pop())
                p['searched']+=1
                p['last_search_round']=hg_round
                lines.append((None,'{}在场景{}搜到一张牌，现在有{}张。'.format(p['name'],p['room'],len(p['hand']))))
                continue
            eligible=[q for q in hg_players if q is not p and q['room']==p['room'] and p['hand'] and q['hand']
                and p['id'] not in fought and q['id'] not in fought
                and tuple(sorted((p['id'],q['id']))) not in hg_pairs]
            battled=False
            if eligible and renpy.random.random()<p['aggression']:
                q=(min(eligible,key=lambda x:hg_estimate(p,x)) if p['family'] in ('估牌择战型','情报择牌型') else renpy.random.choice(eligible))
                attractive=max(p['hand'])>=hg_estimate(p,q) or p['special']=='小牌'
                if p['family'] not in ('估牌择战型','谨慎反击型','保牌避战型') or attractive:
                    lines.append((p['name'],p['opening']))
                    lines.append((p['name'],'{}，和我打一场。'.format(q['name'])))
                    # Pre-duel talk is separate; only concrete false card reports incur penalties.
                    hg_report(q,p,lines,'决斗前交涉')
                    hg_report(p,q,lines,'决斗前交涉')
                    # Reports matter to consent, as well as subsequent card/special choices.
                    confidence=max(q['hand'])-hg_estimate(q,p)
                    chance=max(.02,min(.98,q['acceptance']+.04*confidence))
                    consent=renpy.random.random()<chance
                    lines.append((q['name'],HG_STYLE[q['family']][1 if consent else 2]))
                    if consent or p['force']>0:
                        forced=not consent
                        if forced:
                            p['force']-=1
                            lines.append((p['name'],'我使用强制机会。这一场，你必须接。'))
                        hg_duel(p,q,forced,lines)
                        fought.update((p['id'],q['id']))
                        battled=True
                    else:
                        lines.append((None,'对方拒绝，强制机会也已用尽；挑战取消。'))
            if not battled:
                choices=HG_MAP[p['room']]
                if renpy.random.random()<p['exploration']:
                    best=max(len(hg_rooms[i]) for i in choices)
                    choices=[i for i in choices if len(hg_rooms[i])==best]
                old=p['room']
                p['room']=renpy.random.choice(choices)
                lines.append((None,'{}：场景{} → 场景{}。'.format(p['name'],old,p['room'])))
        if hg_round in (5,10):
            ranking=sorted(hg_players,key=lambda p:p['score'],reverse=True)
            lines.append(('主持人','当前积分排名公布。'))
            for rank,p in enumerate(ranking,1):
                lines.append((None,'第{}名 {}：积分{}。'.format(1+sum(q['score']>p['score'] for q in hg_players),p['name'],p['score'])))
                p['aggression']=max(0,min(1,p['aggression']+(.15 if rank>16 else -.05)))
        assert sum(len(v) for v in hg_rooms.values())+sum(len(p['hand'])+p['discarded'] for p in hg_players)==104
        duels=[e for e in hg_history if e['phase']=='决斗']
        assert sum(p['score'] for p in hg_players)==10*sum(e['result']!=0 for e in duels)+sum(p['bonus']+p.get('truth_bonus',0)-p['penalty']-5*p['lies'] for p in hg_players)
        return lines

    def hg_finish():
        global hg_final
        if hg_round<12: return [(None,'游戏尚未结束。')]
        if not hg_final:
            ranking=list(hg_players)
            renpy.random.shuffle(ranking)
            ranking.sort(key=lambda p:(hg_total(p),p['score']),reverse=True)
            hg_final=[p['id'] for p in ranking]
        return [('主持人','最终结果公布，前16名存活。')] + [(None,'第{}名 {}：{}分，{}。'.format(i+1,hg_players[pid]['name'],hg_total(hg_players[pid]),'存活' if i<16 else '淘汰')) for i,pid in enumerate(hg_final)]

screen hg_roster():
    modal True
    frame:
        xfill True
        yfill True
        vbox:
            spacing 12
            text "26名NPC · 观察者资料（含性格，非玩家公开情报）"
            viewport:
                mousewheel True
                draggable True
                scrollbars "vertical"
                yfill True
                vbox:
                    spacing 10
                    for p in hg_players:
                        $ card_count = len(p['hand'])
                        text "[p['name']]｜[p['family']]｜[p['temperament']]"
                        text "场景[p['room']] · 手牌[card_count]张 · 积分保密 · 强制机会[p['force']]"
            textbutton "返回" action Return()
