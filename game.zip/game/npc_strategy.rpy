# Personality-aware decisions. Opponent hands are only read for public counts.
init 20 python:
    HG_NAMES = ['许随安','陆一鸣','唐小禾','周遇','沈砚锋','雷烈','顾追岚',
        '裴峥','秦霸川','韩知界','江寂','林慎微','苏藏锋','钱守余','叶寻夏',
        '陈负山','温藏玉','程知衡','柳弈秋','杜逢时','方守成','宋知礼',
        '白闻舟','林岑','夏逐风','许定远']
    HG_PROFILES = [(HG_NAMES[i]+'·'+v[0].split('·')[-1],)+tuple(v[1:])
        for i,v in enumerate(HG_PROFILES)]

    def hg_sync_names():
        for p in hg_players:
            if p['special']=='交换': p['special']='保留'
            if p['id'] != PG_ID and not p.get('human',False):
                p['name'] = HG_PROFILES[p['id']][0]
                p['opening'] = HG_VOICES[p['id']][2]

    def hg_known_score(p,q):
        if p is q: return p['score']
        # Only the frozen published scoreboard is known, never live opponent score.
        for row in pg_announced:
            if row['id']==q['id']: return row['score']
        return 0  # Opening score is known; later hidden changes remain uncertain.

    def hg_talk_risk(p):
        # Talk follows actions, so this estimates next-round exposure to everyone listening.
        if not p['hand'] or hg_round>=12: return 0.0
        threats=[q for q in hg_players if q is not p and q['room']==p['room']
            and q['hand'] and tuple(sorted((p['id'],q['id']))) not in hg_pairs]
        pressure=sum((.3+q['aggression'])*(1 if q['force']>0 else .25) for q in threats)
        weakness=sum(v<=8 for v in p['hand'])/float(len(p['hand']))
        return min(1.0,pressure*(.15+.4*weakness)/max(1,len(p['hand'])**.5))

    def hg_talk_role(p,q):
        if not p['hand']: return 'ask'
        if not q['hand']: return 'reveal'
        risk=hg_talk_risk(p)
        # Safe truth earns five only while this partner's reward remains unused.
        if risk<.25 and hg_report_score(p,q)>0: return 'reveal'
        curiosity={'情报择牌型':.8,'估牌择战型':.65,'谨慎反击型':.7,
            '保牌避战型':.75,'高频强攻型':.35,'随机出牌型':.2}.get(p['family'],.5)
        report=p['info'].get(q['id'])
        fresh=report and report[1]==len(q['hand']) and hg_round-report[2]<=1
        return 'ask' if renpy.random.random()<curiosity*risk*(.4 if fresh else 1) else 'reveal'

    # 每位NPC：(主动透露自己的牌时的开场白，询问对方的牌时的开场白)。
    # 使用固定人物ID，修改姓名或读取旧存档不会串台词；23号为玩家席位。
    HG_TALK_OPENINGS = {
        0: ('我先告诉你一张吧，说实话还能赚点分。',
            '你手里有什么牌呀？说一张就行，我相信你，兄弟。'),  # 许随安·随性客
        1: ('来，先听听我的牌，说不定你想跟我玩玩？',
            '让我猜猜，你是不是藏了张大的？说出来让我感受一下。'),  # 陆一鸣·赌徒
        2: ('先告诉你一张我的牌吧，我不会告诉别人的',
            '欸，你搜到什么牌了？我还挺好奇这间屋子里都藏了些什么。'),  # 唐小禾·漫游者
        3: ('我先说我的，信不信你自己决定',
            '正好碰上，你什么牌？应该不会比我的更大了吧。'),  # 周遇·机会主义者
        4: ('我透露一张我的牌，你自己掂量。不要找错对手哦。',
            '报一张牌。我想看看，这里有没有值得我出手的猎物。'),  # 沈砚锋·猎手
        5: ('听着，我先报一张！省的说我欺负人。',
            '少磨叽，你什么牌？不想说吗，哈哈！那我要决斗你了！'),  # 雷烈·狂战士
        6: ('先听听我的牌？别怕，你不在我的目标里',
            '别急着去别处，先说说你的牌。我得知道谁是敌人谁是朋友。'),  # 顾追岚·追击者
        7: ('我先说我的，你再说你的，可以吧？',
            '报一张你的牌吧，我想知道，与你较量值不值得出这张牌。'),  # 裴峥·决斗家
        8: ('我先报一张，你听仔细了，再想想要不要与我为敌。',
            '你的牌，报一张。别逼我把话问第二遍。你要是心虚了，我可要决斗你了。'),  # 秦霸川·强征者
        9: ('我只透露一张。知道彼此一点底细，也许就不用动手。',
            '你愿意报一张牌吗？我得先确认，你会不会对我动手。'),  # 韩知界·守卫
        10: ('我只说一张，我说完你就当没听过。咱们井水不犯河水。',
             '你的牌，说一张就好。我只想知道到底谁是危险人物。'),  # 江寂·隐士
        11: ('我可以先说一张。你听了这句，可别自以为把我看透了。',
             '先报一张吧。我会斟酌你的话。'),  # 林慎微·谨慎者
        12: ('我先透露一张，你听听就好。想动手之前，多想一步。',
             '方便说一张你的牌吗？放心，人不犯我，我不犯人。'),  # 苏藏锋·反击者
        13: ('我先说一张，给你个面子。咱们各留各的牌，都能多算点分。',
             '方便告诉我一张吗？咱们和平为主，携手共赢。'),  # 钱守余·囤积者
        14: ('听我说，我拿到了非常好的牌，想不想听听？',
             '你都搜到什么好牌了？报一张听听，我也去试试手气。'),  # 叶寻夏·寻宝者
        15: ('我先报一张，没什么厉害的。你听完，可别再拿我当对手了。',
             '你说一张牌给我听听吧，我也好知道该往哪边躲。'),  # 陈负山·搬运工
        16: ('我愿意先透露一张。互相留点余地，手里的牌才留得住。',
             '可否让我知道你的一张牌？彼此有个底，也免得伤了和气。'),  # 温藏玉·收藏家
        17: ('透露一张换五分，这笔账划得来。接下来这句话，你也可以算算。',
             '报一张你的牌吧。我想算清楚，一场决斗究竟值多少。'),  # 程知衡·精算师
        18: ('我先给你一条线索。至于能从中看出多少，就看你怎么想了。',
             '不妨说一张你的牌。你想让我相信什么，我很想听听。'),  # 柳弈秋·谋士
        19: ('先送你一点消息，听完再决定，要不要在我身上下注。',
             '透露一张吧？让我看看你值不值得我冒险。'),  # 杜逢时·投机者
        20: ('我先说一张。多拿五分，总比拿一张好牌去冒险强。',
             '说一张你的牌吧。先把可能亏多少弄清楚，省得两败俱伤。'),  # 方守成·保本者
        21: ('我先透露一张，算是一点诚意。咱们可以交个朋友，未必非得动手。',
             '你愿意分享一张牌吗？彼此多了解一点，也好商量接下来怎么走。'),  # 宋知礼·外交官
        22: ('先送你一条关于我的消息。听好了。',
             '报一张你的牌？现在我已经了解了很多人的牌了。'),  # 白闻舟·情报商
        24: ('我先亮一点底，免得光顾着猜。接下来是搜牌还是较量，再看机会！',
             '来，说说你的牌！知道点风险，我才好决定这一把值不值得闯。'),  # 夏逐风·冒险家
        25: ('我先透露一张。其余的慢慢了解，没必要一下把路都走死。',
             '你方便说一张吗？我想先有个底，再决定下一步。'),  # 许定远·稳健者
    }

    def hg_talk_opening(p,q,role):
        phrases = HG_TALK_OPENINGS.get(p['id'], ('我先透露一张自己的牌。', '你愿意说一张自己的牌吗？'))
        phrase = phrases[0 if role=='reveal' else 1]
        if role=='reveal' and hg_report_score(p,q)==0:
            phrase = {
                0:'我再告诉你一张吧，这回就当送你条消息。',
                17:'这次不赚那五分了。透露一点消息，看看能不能换来别的收益。',
                20:'我再说一张。先聊清楚，总比拿一张好牌去冒险强。',
            }.get(p['id'], phrase)
        return q['name']+'，'+phrase

    def hg_belief(p,q):
        # A larger hand offers more choice, not automatic knowledge of its maximum.
        n=max(1,len(q['hand']))
        cautious=q['family'] in ('谨慎反击型','保牌避战型')
        strength=min(n,3.0 if cautious else 1.8)
        weights=[((v-1)/13.0)**strength-((v-2)/13.0)**strength for v in range(2,15)]
        if q['family']=='随机出牌型': weights=[1/13.0]*13
        report=p['info'].get(q['id'])
        secondhand=False
        if not report or report[1]!=n or not 0<=hg_round-report[2]<=2:
            rumor=p.get('rumors',{}).get(q['id'])
            if rumor:
                report=(rumor['value'],rumor['count'],rumor['heard_round'])
                secondhand=True
        if report and report[1]==n and 0<=hg_round-report[2]<=2:
            trust={'随机出牌型':.8,'情报择牌型':.48,'估牌择战型':.38}.get(p['family'],.55)
            if secondhand: trust*=.5
            trust*=.65**(hg_round-report[2])
            # A reported card is only one card and may be a bluff.
            trust/=max(1,n*.6)
            weights=[w*(1-trust)+(trust if v==report[0] else 0) for v,w in zip(range(2,15),weights)]
        return list(zip(range(2,15),weights))

    def hg_estimate(p,q):
        return sum(v*w for v,w in hg_belief(p,q))

    def hg_plan(p,q,forced=False):
        belief=hg_belief(p,q)
        options=[None]
        if p['special']:
            options.append(p['special'])
        choices=[]
        for card in sorted(set(p['hand'])):
            for sp in options:
                value=card+(5 if sp=='加5' else 0)
                win=sum(w for v,w in belief if (value<v if sp=='小牌' else value>v))
                lose=sum(w for v,w in belief if (value>v if sp=='小牌' else value<v))
                card_cost=0 if sp=='保留' else card
                # Ordinary cards are final score: spending an A costs fourteen points.
                reserve=max(0,12-hg_round)*(.55 if sp=='保留' else .35) if sp else 0
                reserve *= 1.5-p['willingness']
                ev=(30 if forced else 20)*win-10*lose-card_cost-reserve
                choices.append((card,sp,ev,win))
        best=max(choices,key=lambda c:(c[2],-c[0],c[1] is None))
        if p['family']=='高频强攻型':
            # Preserve the minimum likely-winning card, including special-card cost.
            winning=[c for c in choices if c[3]>=.65 and c[2]>=best[2]-2]
            if winning: best=min(winning,key=lambda c:(c[0],-c[2]))
        return best

    def hg_commit(p,q):
        if p['family']=='随机出牌型' and renpy.random.random()<.6:
            card=renpy.random.choice(p['hand'])
            # Innocent characters stay unpredictable, but stop wasting obvious specials.
            plans=hg_plan(p,q)
            return (card,plans[1] if plans[0]==card else None)
        best=hg_plan(p,q)
        return best[0],best[1]

    def hg_accept(p,q):
        ev=hg_plan(p,q)[2]
        caution={'保牌避战型':7,'谨慎反击型':4,'估牌择战型':1,
            '情报择牌型':2,'高频强攻型':-5,'随机出牌型':-2}.get(p['family'],1)
        chance=.5+(ev-caution)*.065+(p['acceptance']-.5)*.35
        return renpy.random.random()<max(.02,min(.98,chance))

    def hg_force_worthwhile(p,q):
        ev=hg_plan(p,q,True)[2]
        reserve=max(0,10-hg_round)*(.45 if p['force']==1 else .2)
        threshold={'高频强攻型':-4,'随机出牌型':-2,'保牌避战型':6,
            '谨慎反击型':4}.get(p['family'],0)
        return ev-reserve>=threshold

    def hg_move_value(p,room):
        # Breadth-first distances use the actual bidirectional map.
        dist={room:0}
        todo=[room]
        for r in todo:
            for nxt in HG_MAP[r]:
                if nxt not in dist:
                    dist[nxt]=dist[r]+1
                    todo.append(nxt)
        remaining=12-hg_round
        resource=max([0.0]+[min(len(hg_rooms[r]),3)*2.5/(d+1)
            for r,d in dist.items() if d<remaining])
        people=[q for q in hg_players if q is not p and q['room']==room]
        danger=sum(q['aggression'] for q in people if q['hand'] and q['force']>0)
        family=p['family']
        caution=2.5 if family in ('保牌避战型','谨慎反击型') else .4
        hunting=0
        if p['hand'] and family not in ('保牌避战型','谨慎反击型'):
            prey=[q for q in people if q['hand'] and tuple(sorted((p['id'],q['id']))) not in hg_pairs]
            if prey: hunting=max(0,max(hg_plan(p,q,p['force']>0)[2] for q in prey))*.45
        social=(2 if family=='情报择牌型' else .5) if people and p['hand'] else 0
        return resource+hunting+social-caution*danger

    def hg_ai_action(p,targets):
        if hg_can_search(p) and p['searched']<3: return ('search',None)
        family=p['family']
        if targets:
            options=[]
            for q in targets:
                normal=hg_plan(p,q)
                forced=hg_plan(p,q,True) if p['force']>0 else normal
                # Consent is uncertain; don't assume the forced bonus is guaranteed.
                ev=normal[2]*.55+forced[2]*.45
                options.append((ev,q))
            ev,q=max(options,key=lambda x:x[0])
            bias={'高频强攻型':5,'随机出牌型':2,'保牌避战型':-8,
                '谨慎反击型':-5,'情报择牌型':-1}.get(family,0)
            alternative=8 if hg_can_search(p) else 0
            noise=renpy.random.uniform(-4,4) if family=='随机出牌型' else renpy.random.uniform(-1,1)
            if ev+bias+noise>alternative and renpy.random.random()<min(.98,p['aggression']+.25):
                return ('challenge',q['id'])
        if hg_can_search(p): return ('search',None)
        if hg_round==12: return ('wait',None)
        rooms=[p['room']]+HG_MAP[p['room']]
        values={r:hg_move_value(p,r) for r in rooms}
        values[p['room']]+=.6  # Don't pace pointlessly between equally empty rooms.
        if family=='随机出牌型' and renpy.random.random()<p['exploration']*.25:
            room=renpy.random.choice(HG_MAP[p['room']])
        else:
            room=max(rooms,key=lambda r:values[r]+renpy.random.uniform(0,.3)*p['exploration'])
        return ('wait',None) if room==p['room'] else ('move',room)
