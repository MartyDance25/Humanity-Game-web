# Interactive first round: 23 NPCs + the human player.
default pg_active = False
default pg_at_gate = False
default pg_name = "林岑"
default pg_queue = []
default pg_event = None
default pg_fought = []
default pg_lines = []
default pg_index = 0
default pg_speaker = None
default pg_text = ""
default pg_public_log = []
default pg_announced = []
default pg_actor = 0
default pg_target = 0
default pg_reporter = 0
default pg_listener = 0
default pg_phase = ""
default pg_reply = None
default pg_consent = False
default pg_forced = False
default pg_battled = False
default pg_choice_a = None
default pg_choice_b = None
default pg_card = None
default pg_special = None
default pg_request = None
default pg_planned_action = None
default pg_finished = False
default pg_subject = None

init 10 python:
    PG_ID = 23
    PG_ROOMS = {1:'普通教室',2:'北侧走廊',3:'图书阅览室',4:'化学实验室',
        5:'东侧走廊',6:'物理实验室',7:'中央庭院',8:'西侧走廊',
        9:'教学楼门厅',10:'南侧连廊',11:'校医室',12:'音乐教室',13:'旧食堂',14:'美术教室'}

    def pg_room_background():
        if pg_at_gate:
            path = 'images/rooms_school_mild/gate.png'
        else:
            room = pg_you()['room'] if pg_active and hg_players else 1
            path = 'images/rooms_school_mild/room{:02d}.png'.format(room)
        return Transform(path, xysize=(1920, 1080), fit='cover')

    pg_text_contrast_cache = {}

    def pg_background_text_dark(room, bounds):
        # Sample the region behind the text in the same centered crop as the background.
        key = (room, bounds)
        if key in pg_text_contrast_cache:
            return pg_text_contrast_cache[key]
        path = 'images/rooms_school_mild/room{:02d}.png'.format(room)
        dark = False
        try:
            surf = renpy.load_surface(path)
            w, h = surf.get_width(), surf.get_height()
            scale = max(1920 / w, 1080 / h)
            crop_x = (w * scale - 1920) / 2
            crop_y = (h * scale - 1080) / 2
            left, top, right, bottom = bounds
            x0, x1 = int((left + crop_x) / scale), int((right + crop_x) / scale)
            y0, y1 = int((top + crop_y) / scale), int((bottom + crop_y) / scale)
            samples = []
            for y in range(max(0, y0), min(h, y1), 12):
                for x in range(max(0, x0), min(w, x1), 12):
                    r, g, b = surf.get_at((x, y))[:3]
                    samples.append(0.2126 * r + 0.7152 * g + 0.0722 * b)
            if samples:
                samples.sort()
                dark = samples[len(samples) // 2] >= 128
        except Exception:
            dark = False
        pg_text_contrast_cache[key] = dark
        return dark
    PG_SPECIALS = {'保留':'本次打出的普通牌不弃置，仍留在手中；无论胜负或平局均有效。特殊卡使用后消耗。',
        '加5':'自己本次判定点数 +5，不增加积分。',
        '小牌':'本次判定改为小牌获胜，加成仍先生效。',
        '任选':'剩余1次；决斗时可选保留、加5或小牌之一，使用后整张特殊卡消耗。'}
    PG_POS = {1:(50,30),2:(190,90),6:(430,30),5:(240,200),4:(450,180),
        3:(310,310),8:(35,270),7:(170,400),12:(25,490),9:(350,480),10:(490,380),
        11:(270,590),13:(470,590)}

    def pg_you():
        return hg_players[PG_ID]

    def pg_portrait(pid):
        return 'images/portraits/npc{:02d}.png'.format(HG_SOURCE_IDS[pid])

    def pg_face(who):
        if who == '主持人': return 'images/主持人.png'
        for p in hg_players:
            if p['name'] == who: return pg_portrait(p['id'])
        return None

    def pg_rank(v):
        return {11:'J',12:'Q',13:'K',14:'A'}.get(v,str(v))

    def pg_start():
        global pg_active, pg_queue, pg_fought, pg_public_log, pg_announced, pg_finished, PG_ID
        PG_ID=HG_SINGLE_PLAYER_ID
        pg_set_dialogue()
        hg_reset()
        p=pg_you()
        p['name']=pg_name
        p['temperament']='你的选择，决定你是什么样的人。'
        p['opening']='先听听彼此怎么说。'
        pg_active=True
        pg_finished=False
        pg_queue=[]
        pg_fought=[]
        pg_public_log=[]
        pg_announced=[]

    def pg_visible(p):
        return p['room']==pg_you()['room']

    def pg_targets(p):
        if not p['hand'] or p['id'] in pg_fought: return []
        return [q for q in hg_players if q is not p and q['room']==p['room'] and q['hand']
            and q['id'] not in pg_fought and tuple(sorted((p['id'],q['id']))) not in hg_pairs]

    def pg_begin_round():
        global hg_round, pg_queue, pg_fought, pg_planned_action
        hg_sync_names()
        assert hg_round<12
        hg_round+=1
        pg_fought=[]
        order=list(hg_players)
        renpy.random.shuffle(order)
        order.sort(key=lambda p:p['score'],reverse=True)
        pg_planned_action=None
        pg_queue=[dict(kind='action',actor=p['id']) for p in order]
        pg_queue.append(dict(kind='prepare_talk',order=[p['id'] for p in order]))
        return [('主持人','第 {} / 12 回合。按积分顺序选择并执行主行动，行动结束后再进行回合交谈。'.format(hg_round))]

    def pg_prepare_talk(order):
        # Every participant owns one initiation; receiving never consumes it.
        pg_queue[0:0]=[dict(kind='choose_talk',actor=pid) for pid in order]

    def pg_offer_talk(pid):
        used=[e.get('initiator',e['ids'][0]) for e in hg_history
            if e['round']==hg_round and e['phase']=='配对']
        if pid in used: return
        p=hg_players[pid]
        peers=[q for q in hg_players if q is not p and q['room']==p['room']]
        if not peers:
            if pid==PG_ID:
                pg_queue.insert(0,dict(kind='notice',text='没有同场景的交谈对象，本回合跳过主动交谈。'))
            return
        if pid==PG_ID:
            pg_queue.insert(0,dict(kind='human_talk',peers=[q['id'] for q in peers]))
        else:
            pg_queue.insert(0,dict(kind='talk',actor=pid))

    def pg_npc_pairs(order):
        pg_queue[0:0]=[dict(kind='choose_talk',actor=pid) for pid in order if pid!=PG_ID]

    def pg_pair(a,b):
        prior=[e.get('initiator',e['ids'][0]) for e in hg_history
            if e['round']==hg_round and e['phase']=='配对']
        assert a not in prior
        assert a!=b and hg_players[a]['room']==hg_players[b]['room']
        hg_history.append(dict(round=hg_round,phase='配对',ids=[a,b],initiator=a))

    def pg_ai_action(pid):
        p=hg_players[pid]
        return hg_ai_action(p,pg_targets(p))

    def pg_do_action(pid,kind,dest=None):
        p=hg_players[pid]
        visible=pg_visible(p)
        if kind=='search':
            assert hg_can_search(p), '不得连续两回合搜寻卡牌'
            card=hg_rooms[p['room']].pop()
            p['hand'].append(card)
            p['searched']+=1
            p['last_search_round']=hg_round
            message='你搜到了{}。'.format(hg_card_name(card)) if pid==PG_ID else '{}搜到一张牌，现有{}张。'.format(p['name'],len(p['hand']))
        elif kind=='move':
            assert dest in HG_MAP[p['room']]
            old=p['room']
            p['room']=dest
            message='{}从{}移往{}。'.format(p['name'],PG_ROOMS[old],PG_ROOMS[dest])
            visible=visible or pg_visible(p)
        else:
            assert kind=='wait'
            message='{}选择等待。'.format(p['name'])
        hg_history.append(dict(round=hg_round,phase='主行动',actor=pid,action=kind))
        return [(None,message)] if visible else []

    def pg_finish_action(pid):
        hg_history.append(dict(round=hg_round,phase='主行动',actor=pid,action='challenge'))

    def pg_close_round():
        global pg_announced
        # Information hiding is a UI rule; audit state retains exact hands/claims.
        assert sum(len(v) for v in hg_rooms.values())+sum(len(p['hand'])+p['discarded'] for p in hg_players)==104
        assert len(hg_pairs)==len(set(hg_pairs))
        hg_assert_score_balance()
        acts=[e['actor'] for e in hg_history if e['round']==hg_round and e['phase']=='主行动']
        assert sorted(acts)==list(range(HG_PLAYER_COUNT))
        lines=[(None,'第{}回合结束。你的积分{}，手牌{}张，当前总分{}。'.format(hg_round,pg_you()['score'],len(pg_you()['hand']),hg_total(pg_you())))]
        if hg_round in (5,10):
            ranking=sorted(hg_players,key=lambda p:p['score'],reverse=True)
            pg_announced=[dict(name=p['name'],id=p['id'],score=p['score'],rank=1+sum(q['score']>p['score'] for q in hg_players),round=hg_round) for i,p in enumerate(ranking)]
            for i,p in enumerate(ranking):
                p['aggression']=max(0,min(1,p['aggression']+(.15 if i>=16 else -.05)))
            lines.append(('主持人','第{}回合积分榜已公布，可在情报面板查阅。'.format(hg_round)))
        return lines

    class PGMapLines(renpy.Displayable):
        def render(self,width,height,st,at):
            r=renpy.Render(620,700)
            c=r.canvas()
            for a,b in HG_MAP_EDGES:
                x,y=PG_POS[a]; xx,yy=PG_POS[b]
                c.line('#52636d',(x+45,y+30),(xx+45,yy+30),3)
            return r

    def pg_fullscreen_map():
        xs = [xy[0] for xy in PG_POS.values()]
        ys = [xy[1] for xy in PG_POS.values()]
        minx, maxx = min(xs), max(xs)
        miny, maxy = min(ys), max(ys)
        node_w, node_h = 168, 120
        left, top, right, bottom = 48, 130, 1872, 1032
        span_x = float(max(1, maxx - minx))
        span_y = float(max(1, maxy - miny))
        sx = (right - left - node_w) / span_x
        sy = (bottom - top - node_h) / span_y
        pos = {}
        for room_id, xy in PG_POS.items():
            pos[room_id] = (int(left + (xy[0] - minx) * sx), int(top + (xy[1] - miny) * sy))
        return pos, node_w, node_h

    class PGFullMapLines(renpy.Displayable):
        def __init__(self, pos, node_w, node_h, **kwargs):
            super(PGFullMapLines, self).__init__(**kwargs)
            self.pos = pos
            self.node_w = node_w
            self.node_h = node_h

        def render(self, width, height, st, at):
            r = renpy.Render(1920, 1080)
            c = r.canvas()
            for a, b in HG_MAP_EDGES:
                x, y = self.pos[a]
                xx, yy = self.pos[b]
                c.line('#8aa0ab', (x + self.node_w / 2, y + self.node_h / 2), (xx + self.node_w / 2, yy + self.node_h / 2), 5)
            return r

label pg_begin:
    $ pg_active = False
    scene expression Solid('#101820')
    $ pg_name = renpy.input('你的名字（最多8个字）', default='林岑', length=8, exclude='[]{}%\n\r').strip() or '林岑'
    if pg_name in [p[0] for i,p in enumerate(HG_PROFILES) if i != PG_ID] or pg_name == '主持人':
        $ pg_name = pg_name + '（你）'
    $ pg_start()
    play music "audio/Tick Tack.mp3" loop fadein 2.0 volume 0.45
    $ pg_at_gate = True
    call hg_rules
    $ pg_at_gate = False
    $ pg_lines = [(None,'你与23名陌生人进入了同一场游戏。'), (None,'你在{}醒来。你有1次特殊卡使用机会，决斗时可从保留、加5、小牌中任选一种效果。'.format(PG_ROOMS[pg_you()['room']])), (None,'按右键或Esc可保存与读取。')]
    call pg_show_lines
    jump pg_round_loop

label pg_show_lines:
    $ pg_index = 0
    while pg_index < len(pg_lines):
        $ pg_speaker, pg_text = pg_lines[pg_index]
        $ pg_public_log.append((hg_round, pg_speaker or '记录', pg_text))
        $ hg_say_line(pg_speaker, pg_text)
        $ pg_index += 1
    return

label pg_round_loop:
    $ pg_set_dialogue()
    if hg_round >= 12:
        jump pg_ending
    $ pg_lines = pg_begin_round()
    call pg_show_lines
    jump pg_event_loop

label pg_event_loop:
    if not pg_queue:
        $ pg_set_dialogue()
        $ pg_lines = pg_close_round()
        call pg_show_lines
        if hg_round in (5,10):
            call screen pg_info('ranking', True)
        jump pg_round_loop
    $ pg_event = pg_queue.pop(0)
    if pg_event['kind'] == 'prepare_talk':
        $ pg_prepare_talk(pg_event['order'])
    elif pg_event['kind'] == 'choose_talk':
        $ pg_offer_talk(pg_event['actor'])
    elif pg_event['kind'] == 'choose_action':
        call screen pg_action
        $ pg_planned_action = _return
    elif pg_event['kind'] == 'notice':
        $ pg_lines = [(None,pg_event['text'])]
        call pg_show_lines
    elif pg_event['kind'] == 'npc_talk_phase':
        $ pg_npc_pairs(pg_event['order'])
    elif pg_event['kind'] == 'human_talk':
        call screen pg_partner(pg_event['peers'])
        if _return == 'skip':
            jump pg_event_loop
        $ pg_actor, pg_target = PG_ID, _return
        $ pg_set_dialogue(pg_actor,pg_target)
        $ pg_pair(pg_actor,pg_target)
        $ pg_lines = [(pg_you()['name'],'先聊一聊吧。'),(hg_players[pg_target]['name'],hg_players[pg_target]['opening'])]
        call pg_show_lines
        call screen pg_talk_role
        if _return == 'gossip':
            call screen pg_gossip_target(pg_actor, pg_target)
            $ pg_subject = _return
            call pg_gossip_label
        else:
            $ pg_reporter, pg_listener = (pg_target,PG_ID) if _return == 'ask' else (PG_ID,pg_target)
            $ pg_phase = '回合交谈'
            call pg_report_label
    elif pg_event['kind'] == 'talk':
        $ pg_actor = pg_event['actor']
        $ pg_talk_plan = pg_npc_talk_plan(hg_players[pg_actor], [q for q in hg_players if q['id'] != pg_actor and q['room'] == hg_players[pg_actor]['room']])
        if pg_talk_plan is not None:
            $ pg_target, pg_reply, pg_subject = pg_talk_plan
            $ pg_set_dialogue(pg_actor,pg_target)
            $ pg_pair(pg_actor,pg_target)
            if pg_reply == 'gossip':
                call pg_gossip_label
            else:
                $ pg_lines = [(hg_players[pg_actor]['name'],hg_talk_opening(hg_players[pg_actor],hg_players[pg_target],pg_reply))] if pg_visible(hg_players[pg_actor]) else []
                call pg_show_lines
                $ pg_reporter, pg_listener = (pg_actor,pg_target) if pg_reply == 'reveal' else (pg_target,pg_actor)
                $ pg_phase = '回合交谈'
                call pg_report_label
    elif pg_event['kind'] == 'action':
        $ pg_actor = pg_event['actor']
        call pg_action_label
    jump pg_event_loop

label pg_gossip_label:
    $ pg_set_dialogue(pg_actor,pg_target)
    $ pg_lines = [(hg_players[pg_actor]['name'],'{}，你知道{}的牌吗？'.format(hg_players[pg_target]['name'],hg_players[pg_subject]['name']))] if pg_visible(hg_players[pg_actor]) else []
    call pg_show_lines
    if pg_target == PG_ID:
        call screen pg_gossip_reply(pg_subject)
        $ pg_reply = _return
    else:
        $ pg_reply = pg_npc_gossip_reply(hg_players[pg_target],pg_subject)
    $ pg_lines = pg_gossip_report(pg_actor,pg_target,pg_subject,pg_reply)
    if pg_visible(hg_players[pg_actor]):
        call pg_show_lines
    return

label pg_report_label:
    $ pg_set_dialogue(pg_reporter,pg_listener)
    $ pg_lines = []
    if pg_reporter == PG_ID and pg_you()['hand']:
        call screen pg_report_choice
        $ hg_report(pg_you(),hg_players[pg_listener],pg_lines,pg_phase,declared=_return)
    else:
        $ hg_report(hg_players[pg_reporter],hg_players[pg_listener],pg_lines,pg_phase)
    if pg_visible(hg_players[pg_reporter]):
        call pg_show_lines
    return

label pg_action_label:
    $ pg_set_dialogue()
    if pg_actor == PG_ID:
        if pg_planned_action is not None:
            $ pg_request = pg_planned_action
            $ pg_planned_action = None
            if (pg_request[0] == 'search' and not hg_can_search(pg_you())) or (pg_request[0] == 'challenge' and pg_request[1] not in [p['id'] for p in pg_targets(pg_you())]):
                $ pg_lines = [(None,'局势已经变化，原定行动无法执行。请重新选择主行动，本回合交谈不会重复。')]
                call pg_show_lines
                jump pg_action_label
        else:
            call screen pg_action
            $ pg_request = _return
    else:
        $ pg_request = pg_ai_action(pg_actor)
    if pg_request[0] == 'challenge':
        $ pg_target = pg_request[1]
        call pg_challenge_label
        if not pg_battled:
            if pg_actor == PG_ID:
                jump pg_action_label
            else:
                $ pg_lines = pg_do_action(pg_actor,'move',renpy.random.choice(HG_MAP[hg_players[pg_actor]['room']]))
                call pg_show_lines
    else:
        $ pg_lines = pg_do_action(pg_actor,pg_request[0],pg_request[1])
        call pg_show_lines
    return

label pg_challenge_label:
    $ pg_set_dialogue(pg_actor,pg_target)
    $ pg_battled = False
    $ pg_forced = False
    $ pg_consent = False
    $ pg_lines = []
    if pg_visible(hg_players[pg_actor]):
        $ pg_lines = [(hg_players[pg_actor]['name'],hg_players[pg_actor]['opening']), (hg_players[pg_actor]['name'],'{}，和我打一场。'.format(hg_players[pg_target]['name']))]
    call pg_show_lines
    $ pg_reporter, pg_listener, pg_phase = pg_target, pg_actor, '决斗前交涉'
    call pg_report_label
    $ pg_reporter, pg_listener = pg_actor, pg_target
    call pg_report_label
    if pg_target == PG_ID:
        call screen pg_accept(pg_actor)
        $ pg_consent = _return
    else:
        $ pg_consent = hg_accept(hg_players[pg_target],hg_players[pg_actor])
    if pg_visible(hg_players[pg_actor]):
        $ pg_lines = [(hg_players[pg_target]['name'],('我同意。' if pg_consent else '我拒绝。') if pg_target == PG_ID else HG_STYLE[hg_players[pg_target]['family']][1 if pg_consent else 2])]
        call pg_show_lines
    if not pg_consent and hg_players[pg_actor]['force'] > 0:
        if pg_actor == PG_ID:
            call screen pg_force_choice
            $ pg_forced = _return
        else:
            $ pg_forced = hg_force_worthwhile(hg_players[pg_actor],hg_players[pg_target])
        if pg_forced:
            $ hg_players[pg_actor]['force'] -= 1
            if pg_visible(hg_players[pg_actor]):
                $ pg_lines = [(hg_players[pg_actor]['name'],'我使用强制机会。这一场，不能拒绝。')]
                call pg_show_lines
    if not pg_consent and not pg_forced:
        if pg_visible(hg_players[pg_actor]):
            $ pg_lines = [(None,'挑战未成立，没有消耗主行动。决斗前交涉不计分。')]
            call pg_show_lines
        return
    # Hidden NPC commits are fixed BEFORE the player's card/special screens.
    $ pg_choice_a = hg_commit(hg_players[pg_actor],hg_players[pg_target]) if pg_actor != PG_ID else None
    $ pg_choice_b = hg_commit(hg_players[pg_target],hg_players[pg_actor]) if pg_target != PG_ID else None
    if PG_ID in (pg_actor,pg_target):
        call screen pg_card_choice(pg_target if pg_actor == PG_ID else pg_actor)
        $ pg_card = _return
        if pg_you()['special']:
            call screen pg_special_choice
            $ pg_special = None if _return == 'keep' else _return
        else:
            $ pg_special = None
        if pg_actor == PG_ID:
            $ pg_choice_a = (pg_card,pg_special)
        else:
            $ pg_choice_b = (pg_card,pg_special)
    $ pg_lines = []
    $ hg_duel(hg_players[pg_actor],hg_players[pg_target],pg_forced,pg_lines,pg_choice_a,pg_choice_b)
    $ pg_fought.extend((pg_actor,pg_target))
    $ pg_finish_action(pg_actor)
    $ pg_battled = True
    if pg_visible(hg_players[pg_actor]):
        call pg_show_lines
    return

label pg_ending:
    $ pg_lines = hg_finish()
    $ pg_finished = True
    call screen pg_results
    stop music fadeout 2.0
    $ pg_active = False
    return
