# Original IDs are retained for portraits/dialogue; gameplay IDs remain dense.
init 30 python:
    HG_SOURCE_IDS = tuple(i for i in range(26) if i not in (2,15))
    HG_PLAYER_COUNT = len(HG_SOURCE_IDS)
    HG_SINGLE_PLAYER_ID = HG_SOURCE_IDS.index(23)
    HG_PROFILES = [HG_PROFILES[i] for i in HG_SOURCE_IDS]
    HG_VOICES = [HG_VOICES[i] for i in HG_SOURCE_IDS]
    HG_NAMES = [HG_NAMES[i] for i in HG_SOURCE_IDS]
    HG_TALK_OPENINGS = {i:HG_TALK_OPENINGS[source] for i,source in enumerate(HG_SOURCE_IDS) if source in HG_TALK_OPENINGS}
    PG_ID = HG_SINGLE_PLAYER_ID
    HG_SPAWN_ROOMS = (1,3,4,6,11,12,13,14)
    # Ground-floor U-shaped school: perimeter classrooms open onto inner corridors.
    # Eight spawn rooms are leaves; only the six circulation hubs connect each other.
    HG_MAP_EDGES = ((1,2),(6,2),(3,8),(12,8),(4,5),(14,5),(11,10),(13,10),
        (2,8),(2,5),(8,7),(5,7),(8,9),(5,9),(7,9),(9,10))
    HG_MAP = {i:[] for i in range(1,15)}
    for a,b in HG_MAP_EDGES:
        HG_MAP[a].append(b)
        HG_MAP[b].append(a)
    PG_ROOMS = {1:'普通教室',2:'北侧走廊',3:'图书阅览室',4:'化学实验室',
        5:'东侧走廊',6:'物理实验室',7:'中央庭院',8:'西侧走廊',
        9:'教学楼门厅',10:'南侧连廊',11:'校医室',12:'音乐教室',13:'旧食堂',14:'美术教室'}
    # North is up. Spawn rooms lie around the boundary, with no unrelated room shortcuts.
    PG_POS = {1:(20,10),6:(470,10),3:(0,225),4:(495,225),
        12:(0,435),14:(495,435),11:(20,650),13:(470,650),
        2:(245,110),8:(120,310),5:(370,310),7:(245,310),9:(245,465),10:(245,580)}
    # Per-role hand reserve, resource priority and additional combat bias.
    # Values are indexed by original character, never by a renumbered portrait ID.
    HG_ROUTE_PLANS = {
        0:(3,1.0,0),1:(2,.7,3),3:(3,.9,1),4:(3,.8,3),5:(2,.6,5),
        6:(3,1.0,2),7:(3,.9,2),8:(2,.7,4),9:(4,1.25,-2),10:(4,1.4,-4),
        11:(4,1.3,-3),12:(3,1.1,-1),13:(5,1.5,-5),14:(5,1.8,-3),
        16:(5,1.5,-4),17:(3,1.15,1),18:(3,1.1,0),19:(3,1.0,2),
        20:(4,1.3,-2),21:(3,1.1,-1),22:(3,1.05,0),23:(3,1.0,0),
        24:(3,1.1,2),25:(4,1.2,-1)}

    def hg_route_plan(p):
        return HG_ROUTE_PLANS[HG_SOURCE_IDS[p['id']]]
