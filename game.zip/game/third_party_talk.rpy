# Second-hand reports never inspect the subject's hidden hand or change scores.
init 25 python:
    def pg_gossip_subjects(asker, responder):
        room = hg_players[asker]['room']
        if asker == responder or hg_players[responder]['room'] != room:
            return []
        return [p['id'] for p in hg_players
            if p['room'] == room and p['id'] not in (asker, responder)]

    def pg_known_report(person, subject):
        reports = []
        direct = person['info'].get(subject)
        if direct:
            reports.append(direct)
        rumor = person.get('rumors', {}).get(subject)
        if rumor:
            reports.append((rumor['value'], rumor['count'], rumor['heard_round']))
        return max(reports, key=lambda r: r[2]) if reports else None

    def pg_npc_talk_plan(person, peers):
        # Choose the action and its target together, after earlier conversations.
        askable = [q for q in peers if hg_can_ask_card(person, q)]
        rewarding = [q for q in peers if hg_report_score(person, q)]
        if not askable and not rewarding:
            return None

        curiosity = {'情报择牌型': .8, '估牌择战型': .65, '谨慎反击型': .7,
            '保牌避战型': .75, '高频强攻型': .35, '随机出牌型': .2}.get(person['family'], .5)
        if rewarding:
            risk = hg_talk_risk(person)
            if not askable or risk < .25 or renpy.random.random() >= curiosity * risk:
                return (renpy.random.choice(rewarding)['id'], 'reveal', None)

        # A current second-hand report can still be checked by asking its subject.
        # For gossip, prefer a subject for whom we have no current report at all.
        partner_ids = {q['id'] for q in peers}
        gossip = []
        for subject in askable:
            known = pg_known_report(person, subject['id'])
            if known and known[1] == len(subject['hand']) and known[2] == hg_round:
                continue
            gossip.extend((pid, subject['id']) for pid in sorted(partner_ids - {subject['id']}))
        chance = .4 if person['family'] == '情报择牌型' else .2
        if gossip and renpy.random.random() < chance:
            partner, subject = renpy.random.choice(gossip)
            return (partner, 'gossip', subject)

        target = max(askable, key=lambda q: (q['id'] not in person['info'], renpy.random.random()))
        return (target['id'], 'ask', None)

    def pg_gossip_lie_values(person, subject):
        known = pg_known_report(person, subject)
        return [v for v in range(2, 15) if not known or v != known[0]]

    def pg_npc_gossip_reply(person, subject):
        if renpy.random.random() < person['lie_rate']:
            return renpy.random.choice(pg_gossip_lie_values(person, subject))
        if pg_known_report(person, subject) and renpy.random.random() < .85:
            return 'truth'
        return 'unknown'

    def pg_gossip_report(asker, responder, subject, reply):
        assert subject in pg_gossip_subjects(asker, responder)
        speaker = hg_players[responder]
        target = hg_players[subject]
        known = pg_known_report(speaker, subject)
        if reply == 'truth' and known:
            value, count, heard_round = known
            message = '我听说{}有一张{}，是第{}回合的消息，不知道还对不对。'.format(target['name'], pg_rank(value), heard_round)
        elif reply in ('truth', 'unknown'):
            value = count = heard_round = None
            message = '我不知道{}的牌。'.format(target['name'])
        else:
            assert isinstance(reply, int) and reply in pg_gossip_lie_values(speaker, subject)
            value, count, heard_round = reply, len(target['hand']), hg_round
            message = '我听说{}有一张{}。'.format(target['name'], pg_rank(value))
        listeners = [p for p in hg_players if p['room'] == speaker['room'] and p is not speaker]
        if value is not None:
            for person in listeners:
                # The subject knows their own cards. Don't feed a rumor back into its source.
                if person['id'] == subject:
                    continue
                rumors = person.setdefault('rumors', {})
                rumors[subject] = dict(value=value, count=count, heard_round=heard_round,
                    round=hg_round, source=responder)
        hg_history.append(dict(round=hg_round, phase='打听他人', initiator=asker,
            speaker=responder, subject=subject, room=speaker['room'], reported=value,
            reply='truth' if reply == 'truth' and known else 'unknown' if value is None else 'lie',
            overheard_by=[p['id'] for p in listeners if p['id'] != asker]))
        # Intentional deception is audit-only; public dialogue never reveals a truth flag.
        return [(speaker['name'], message)]

screen pg_gossip_target(asker, responder):
    modal True
    add pg_room_background()
    use pg_header('打听别人的牌')
    frame:
        style 'pg_panel'
        xalign .5 ypos 190 xsize 1300 ysize 770
        vbox:
            spacing 20
            text '你想打听谁的牌？' style 'pg_title'
            text '只能选择当前场景的第三人。回答不影响任何人的积分，同场的人也能听到。' style 'pg_small'
            viewport:
                mousewheel True
                scrollbars 'vertical'
                ysize 580
                vbox:
                    spacing 14
                    for pid in pg_gossip_subjects(asker, responder):
                        $ person = hg_players[pid]
                        button:
                            id ('pg_gossip_target_'+str(pid))
                            style 'pg_button'
                            xfill True
                            action Return(pid)
                            hbox:
                                spacing 24
                                add pg_portrait(pid) xysize (90,90)
                                text person['name'] style 'pg_text'

screen pg_gossip_reply(subject):
    modal True
    add pg_room_background()
    use pg_header('回答关于别人的牌')
    use pg_dialogue_portraits(pg_dialogue_people(),pg_you()['name'],compact=True)
    $ person = hg_players[subject]
    $ known = pg_known_report(pg_you(), subject)
    frame:
        style 'pg_panel'
        xalign .5 ypos 190 xsize 1200 ysize 770
        vbox:
            spacing 20
            text ('对方在打听'+person['name']+'的牌') style 'pg_title'
            text '实话、撒谎、不知道，均不加分也不扣分；不消耗你的主动交谈机会。' style 'pg_small'
            text '实话会如实转述你听过的牌点，原消息可能不实或已经过时。' style 'pg_small'
            if known:
                $ known_point = pg_rank(known[0])
                text '你听过的消息：[known_point]（第[known[2]]回合，未经证实）' style 'pg_text'
            else:
                text '你暂时没有此人的牌点情报。' style 'pg_text'
            hbox:
                spacing 20
                textbutton '说实话（转述已知情报）' id 'pg_gossip_truth' style 'pg_button' sensitive known is not None action Return('truth')
                textbutton '不知道' id 'pg_gossip_unknown' style 'pg_button' action Return('unknown')
            text '撒谎：编一个不同于已知消息的牌点。' style 'pg_text'
            vpgrid:
                cols 7
                spacing 12
                ysize 220
                mousewheel True
                for value in pg_gossip_lie_values(pg_you(), subject):
                    textbutton ('谎报 '+pg_rank(value)) id ('pg_gossip_lie_'+str(value)) style 'pg_button' xsize 150 ysize 70 action Return(value)
