default mp_view = {}
default mp_address = ''
default mp_port = '28426'
default mp_code = ''
default mp_notice = ''
default mp_sent_prompt = None
default mp_request = None
default mp_generation = 0

init 35 python:
    import traceback as _mp_traceback
    if renpy.variant('web'):
        import types as _mp_types
        _hg_lan=_mp_types.SimpleNamespace(runtime=None)
    else:
        import hg_multiplayer as _hg_lan

    def mp_is_active():
        return _hg_lan.runtime is not None and not _hg_lan.runtime.closed

    def mp_room_count(room):
        if mp_is_active():
            return mp_view.get('occupants', {}).get(str(room), 0)
        return sum(p['room']==room for p in hg_players)

    def mp_open(mode):
        global mp_notice, mp_sent_prompt, mp_view, mp_generation
        mp_close()
        try:
            port = int(mp_port)
            if not 1 <= port <= 65535:
                raise ValueError('端口须为1至65535之间的整数。')
            if mode=='join' and (not mp_address.strip() or not mp_code.strip()):
                raise ValueError('请填写房主的Tailscale IP和房间码。')
            code = mp_code.strip() or _hg_lan.secrets.token_hex(3).upper()
            room = _hg_lan.Room(None if mode=='host' else mp_address.strip(), port, code,
                store=dict(vars(renpy.store)) if mode=='host' else None)
            room.old_config = {name:getattr(config,name) for name in
                ('rollback_enabled','autosave_frequency','autosave_on_choice','autosave_on_input')}
            config.rollback_enabled=False
            config.autosave_frequency=0
            config.autosave_on_choice=False
            config.autosave_on_input=False
            _hg_lan.runtime=room
            mp_notice=''
            mp_sent_prompt=None
            mp_generation=0
            if room.hosting:
                room.send_view()
            mp_view=room.view
            return True
        except (ValueError,OSError) as error:
            mp_notice='无法建立连接：'+str(error)
            return False

    def mp_close():
        global PG_ID, pg_active, mp_view, mp_sent_prompt, mp_request
        room=_hg_lan.runtime
        if room:
            room.close()
            for name,value in getattr(room,'old_config',{}).items():
                setattr(config,name,value)
        _hg_lan.runtime=None
        PG_ID=HG_SINGLE_PLAYER_ID
        pg_active=False
        pg_set_dialogue()
        mp_sent_prompt=None
        mp_request=None
        mp_view={}

    def mp_select(role):
        if mp_is_active():
            _hg_lan.runtime.submit(dict(type='select',role=role))
            mp_tick()

    def mp_start_room():
        if mp_is_active() and _hg_lan.runtime.hosting:
            try:
                _hg_lan.runtime.start()
            except Exception as error:
                _hg_lan.runtime.close()
                renpy.store.mp_notice='房主处理失败：'+str(error)
                renpy.log(_mp_traceback.format_exc())
            mp_tick()

    def mp_submit(request, value):
        global mp_sent_prompt
        if mp_is_active():
            mp_sent_prompt=request['id']
            try:
                _hg_lan.runtime.submit(dict(type='answer',id=request['id'],value=_hg_lan.wire(value)))
            except Exception as error:
                _hg_lan.runtime.close()
                renpy.store.mp_notice='房主结算失败：'+str(error)
                renpy.log(_mp_traceback.format_exc())
            mp_tick()

    def mp_tick():
        global mp_view, mp_notice, mp_sent_prompt, mp_generation, PG_ID, pg_name, pg_active
        global hg_players,hg_rooms,hg_round,hg_history,hg_pairs,hg_final,pg_fought,pg_announced,pg_public_log
        global pg_actor,pg_target,pg_reporter,pg_listener,pg_phase,pg_subject
        room=_hg_lan.runtime
        if room is None:
            return
        try:
            changed=room.poll()
        except Exception as error:
            room.close()
            mp_notice='联机处理已停止：'+str(error)
            renpy.log(_mp_traceback.format_exc())
            renpy.restart_interaction()
            return
        if getattr(room,'generation',0)!=mp_generation:
            mp_generation=room.generation
            mp_sent_prompt=None
        if getattr(room,'notice',''):
            mp_notice=room.notice
            room.notice=''
            mp_sent_prompt=None
        if not changed and mp_view is room.view:
            return
        mp_view=room.view
        if 'pid' in mp_view:
            PG_ID=mp_view['pid']
            hg_players=[]
            for original in mp_view['players']:
                person=dict(original)
                person['hand']=[HGCard(*card) if isinstance(card,list) else card for card in person['hand']]
                person['info']={int(pid):tuple(report) for pid,report in person['info'].items()}
                person['rumors']={int(pid):dict(report) for pid,report in person['rumors'].items()}
                hg_players.append(person)
            hg_rooms={int(room_id):[0]*count for room_id,count in mp_view['rooms'].items()}
            hg_round=mp_view['round']
            hg_history=mp_view['history']
            hg_pairs=[tuple(pair) for pair in mp_view['pairs']]
            hg_final=mp_view['final']
            pg_fought=mp_view['fought']
            pg_announced=mp_view['ranking']
            pg_public_log=[tuple(line) for line in mp_view['logs']]
            pg_name=hg_players[PG_ID]['name']
            pg_active=True
            prompt=mp_view.get('prompt')
            if prompt:
                # A server returning the same prompt has not accepted the input
                # (for example it arrived during a disconnect pause). Allow retry.
                if prompt['id']==mp_sent_prompt:
                    mp_sent_prompt=None
                context=prompt['context']
                pg_actor=context.get('actor',PG_ID)
                pg_target=context.get('target',PG_ID)
                pg_reporter=context.get('reporter',PG_ID)
                pg_listener=context.get('listener',PG_ID)
                pg_phase=context.get('phase','回合交谈')
                pg_subject=context.get('subject')
                if prompt['kind']=='report':
                    pg_set_dialogue(pg_reporter,pg_listener)
                elif prompt['kind'] in ('role','gossip_target','gossip_reply','accept','force','card','special'):
                    pg_set_dialogue(pg_actor,pg_target)
                else:
                    pg_set_dialogue()
        renpy.restart_interaction()

    def mp_current_prompt():
        prompt=mp_view.get('prompt')
        return prompt if prompt and prompt['id']!=mp_sent_prompt else None

    def mp_membership():
        room=_hg_lan.runtime
        key='host' if room.hosting else getattr(room,'key',None)
        return next((m for m in mp_view.get('members',[]) if m['key']==key),{})

label mp_menu:
    $ mp_notice=''
    $ pg_active=False
    if renpy.variant('web'):
        '多人联机需要桌面版游戏。'
        return
    jump mp_menu_retry

label mp_menu_retry:
    call screen mp_setup
    if _return == 'back':
        return
    if not mp_open(_return):
        jump mp_menu_retry
    show screen mp_network
    call screen mp_lobby
    if _return != 'game':
        jump mp_exit
    play music 'audio/Tick Tack.mp3' loop fadein 2.0 volume .45
    jump mp_play

label mp_play:
    $ mp_tick()
    if not mp_is_active():
        call screen mp_disconnected
        jump mp_exit
    if mp_view.get('phase') == 'result':
        call screen pg_results
        jump mp_exit
    $ mp_request=mp_current_prompt()
    if not mp_request:
        call screen mp_wait
        jump mp_play
    if mp_request['kind']=='action':
        call screen pg_action
    elif mp_request['kind']=='partner':
        call screen pg_partner(mp_request['context']['peers'])
    elif mp_request['kind']=='role':
        call screen pg_talk_role
    elif mp_request['kind']=='report':
        call screen pg_report_choice
    elif mp_request['kind']=='gossip_target':
        call screen pg_gossip_target(pg_actor,pg_target)
    elif mp_request['kind']=='gossip_reply':
        call screen pg_gossip_reply(pg_subject)
    elif mp_request['kind']=='accept':
        call screen pg_accept(mp_request['context']['actor'])
    elif mp_request['kind']=='force':
        call screen pg_force_choice
    elif mp_request['kind']=='card':
        call screen pg_card_choice(mp_request['context']['opponent'])
    elif mp_request['kind']=='special':
        call screen pg_special_choice
    $ mp_submit(mp_request,_return)
    jump mp_play

label mp_failed:
    hide screen mp_network
    hide screen mp_pause
    hide screen pg_info
    call screen mp_disconnected
    jump mp_exit

label mp_exit:
    hide screen mp_network
    hide screen mp_pause
    hide screen pg_info
    $ mp_close()
    stop music fadeout 1.0
    return

screen mp_setup():
    modal True
    default address_input=VariableInputValue('mp_address',default=True)
    default port_input=VariableInputValue('mp_port',default=False)
    default code_input=VariableInputValue('mp_code',default=False)
    add Solid('#101820')
    frame:
        style 'pg_panel'
        xalign .5 yalign .5 xsize 1500
        vbox:
            spacing 22
            text '多人模式 / Tailscale联机' style 'pg_title'
            text '所有人使用相同版本的桌面游戏，并加入同一Tailscale网络。' style 'pg_text'
            text '房主点击创建房间；其他人输入房主的Tailscale IP与房间码后加入。' style 'pg_small'
            text '房主IP（加入房间时填写，例如Tailscale的100.x.x.x地址）' style 'pg_text'
            button:
                background Solid('#253541')
                xfill True
                padding (15,8)
                action address_input.Enable()
                input value address_input length 120 style 'pg_text'
            text 'TCP端口（所有人保持一致）' style 'pg_text'
            button:
                background Solid('#253541')
                xfill True
                padding (15,8)
                action port_input.Enable()
                input value port_input allow '0123456789' length 5 style 'pg_text'
            text '房间码（房主留空自动生成；加入时必填）' style 'pg_text'
            button:
                background Solid('#253541')
                xfill True
                padding (15,8)
                action code_input.Enable()
                input value code_input allow 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789' length 20 style 'pg_text'
            if mp_notice:
                text mp_notice style 'pg_small' color '#ffb6aa'
            hbox:
                spacing 25
                textbutton '创建房间' style 'pg_button' action Return('host')
                textbutton '加入房间' style 'pg_button' action Return('join')
                textbutton '返回' style 'pg_button' action Return('back')

screen mp_network():
    zorder 250
    timer .15 repeat True action Function(mp_tick)
    key 'game_menu' action Show('mp_pause')
    if not mp_is_active():
        timer .05 action Jump('mp_failed')
    if pg_active:
        hbox:
            xpos 1430 ypos 110
            spacing 10
            textbutton '情报 / 对话记录' style 'pg_button' text_size 18 padding (14,6) action Show('pg_info',tab='log')
            textbutton '联机菜单' style 'pg_button' text_size 18 padding (14,6) action Show('mp_pause')

screen mp_lobby():
    modal True
    add Solid('#101820')
    if mp_view.get('phase') in ('game','result'):
        timer .05 action Return('game')
    frame:
        style 'pg_panel'
        xpos 45 ypos 40 xsize 1830 ysize 995
        vbox:
            spacing 16
            text '联机房间 / 选择你喜欢的人物' style 'pg_title'
            $ local_member=mp_membership()
            $ selected=local_member.get('role')
            $ code=mp_view.get('code','连接中')
            $ count=len(mp_view.get('members',[]))
            text '房间码：[code]  /  玩家 [count] / 24  /  TCP端口[mp_port]' style 'pg_text'
            text '同一人物仅限一人；选择随机会在开局时分配未占用角色，其余角色由NPC控制。' style 'pg_small'
            text mp_view.get('status','正在连接…') style 'pg_small'
            if mp_notice:
                text mp_notice style 'pg_small' color '#ffb6aa'
            hbox:
                spacing 20
                textbutton ('✓ 随机分配' if selected is None else '随机分配') style 'pg_button' action Function(mp_select,None)
                if _hg_lan.runtime.hosting:
                    textbutton '开始游戏' style 'pg_button' sensitive count>=2 and all(m.get('connected') for m in mp_view.get('members',[])) action Function(mp_start_room)
                else:
                    text '选好后等待房主开始' style 'pg_text'
                textbutton '离开房间' style 'pg_button' action Return('leave')
            viewport:
                mousewheel True
                draggable True
                scrollbars 'vertical'
                ysize 600
                vpgrid:
                    cols 4
                    spacing 14
                    for pid in range(HG_PLAYER_COUNT):
                        $ occupied=any(m.get('role')==pid and m['key']!=local_member.get('key') for m in mp_view.get('members',[]))
                        button:
                            style 'pg_button'
                            xsize 425 ysize 150
                            sensitive not occupied
                            background Solid('#665638' if selected==pid else '#253541')
                            action Function(mp_select,pid)
                            hbox:
                                spacing 14
                                add pg_portrait(pid) xysize (95,95)
                                vbox:
                                    xsize 265
                                    text HG_PROFILES[pid][0] style 'pg_text' size 23
                                    text HG_PROFILES[pid][1] style 'pg_small' size 19
                                    text ('已被选择' if occupied else '你的选择' if selected==pid else '可选择') style 'pg_small' size 18

screen mp_wait():
    modal True
    add Solid('#101820')
    use pg_header('多人策略战')
    if mp_current_prompt() or mp_view.get('phase')=='result' or not mp_is_active():
        timer .05 action Return()
    frame:
        style 'pg_panel'
        xpos 65 ypos 180 xsize 1790 ysize 800
        vbox:
            spacing 18
            text mp_view.get('status','等待房主同步…') style 'pg_title'
            $ stage=mp_view.get('stage','')
            text '当前阶段：[stage]。可查看情报、规则与对话记录。' style 'pg_small'
            use pg_hand_cards(78,110,1700)
            viewport:
                mousewheel True
                scrollbars 'vertical'
                ysize 440
                vbox:
                    spacing 12
                    for turn,speaker,message in pg_public_log[-12:]:
                        text '[turn] / [speaker]：[message]' style 'pg_text'

screen mp_pause():
    modal True
    zorder 300
    add Solid('#0009')
    frame:
        style 'pg_panel'
        xalign .5 yalign .5 xsize 1000
        vbox:
            spacing 22
            text '联机菜单' style 'pg_title'
            text '联机进度由房主管理，不能使用单机存读档或回退。\n断线时保留游戏窗口，将自动尝试重连。' style 'pg_text'
            if mp_notice:
                text mp_notice style 'pg_small' color '#ffb6aa'
            textbutton '继续游戏' style 'pg_button' action Hide('mp_pause')
            textbutton '规则 / 情报' style 'pg_button' action [Hide('mp_pause'),Show('pg_info',tab='rules')]
            textbutton '离开房间，返回主菜单' style 'pg_button' action Jump('mp_exit')

screen mp_disconnected():
    modal True
    add Solid('#101820')
    frame:
        style 'pg_panel'
        xalign .5 yalign .5 xsize 1200
        vbox:
            spacing 24
            text '联机已停止' style 'pg_title'
            text mp_notice style 'pg_text'
            textbutton '返回主菜单' style 'pg_button' action Return()
